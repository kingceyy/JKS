# plugins/web_app_handler.py

import json
import logging
from pyrogram import Client, filters
from pyrogram.types import Message
from database.jks_db import grant_free_session, format_expiry
from info import LOG_CHANNEL

logger = logging.getLogger(__name__)


# Filtre personnalisé pour détecter les messages web_app_data
# (filters.web_app_data n'existe pas dans pyrofork 2.3.45)
web_app_data_filter = filters.create(
    lambda _, __, message: message.web_app_data is not None,
    name="WebAppDataFilter"
)


@Client.on_message(filters.private & web_app_data_filter)
async def handle_web_app_data(client: Client, message: Message):
    """
    Reçoit les données de la Mini App JKS via Telegram WebApp.sendData().
    Filtre Pyrogram : filtre personnalisé vérifiant message.web_app_data
    Accès aux données : message.web_app_data.data (string JSON)
    """
    user_id = message.from_user.id
    user_mention = message.from_user.mention

    try:
        raw = message.web_app_data.data
        payload = json.loads(raw)
    except Exception as e:
        logger.error(f"[WebApp] Payload invalide reçu de {user_id} : {e}")
        await message.reply_text(
            "<b>Une erreur est survenue.</b>\n\n"
            "Veuillez réessayer depuis la Mini App.\n"
            "Si le problème persiste, contactez le support.",
            parse_mode="html"
        )
        return

    action = payload.get("action")

    # ── Action : pub vue → session 1h ─────────────────────────────────────────
    if action == "ad_watched":
        try:
            expiry = await grant_free_session(user_id)
            expiry_str = format_expiry(expiry)

            await message.reply_text(
                "<b>Session activée avec succès !</b>\n\n"
                "Vous avez maintenant accès à tous les fichiers pendant <b>1 heure</b>.\n\n"
                f"Expiration : <code>{expiry_str}</code>\n\n"
                "Retournez dans le groupe et effectuez vos recherches librement.",
                parse_mode="html"
            )

            # Log dans le channel admin
            await client.send_message(
                chat_id=LOG_CHANNEL,
                text=(
                    "<b>#SESSION_GRATUITE</b>\n\n"
                    f"Utilisateur : {user_mention}\n"
                    f"ID : <code>{user_id}</code>\n"
                    f"Expiration : <code>{expiry_str}</code>\n"
                    f"Méthode : Pub regardée via Mini App"
                ),
                parse_mode="html"
            )

        except Exception as e:
            logger.error(f"[WebApp] Erreur grant_free_session pour {user_id} : {e}")
            await message.reply_text(
                "<b>Erreur lors de l'activation de votre session.</b>\n\n"
                "Veuillez contacter le support.",
                parse_mode="html"
            )

    else:
        logger.warning(f"[WebApp] Action inconnue '{action}' reçue de {user_id}")
