import os
import re, sys
import json
import base64
import logging
import random
import asyncio
import time
import pytz
from database.verify_db import vr_db
from .pmfilter import auto_filter 
from Script import script
from datetime import datetime
from database.refer import referdb
from database.config_db import mdb
from pyrogram import Client, filters, enums
from pyrogram.errors import FloodWait
from pyrogram.types import *
from database.ia_filterdb import Media, Media2, get_file_details, unpack_new_file_id, get_bad_files
from database.users_chats_db import db, delete_all_msg
from info import *
from utils import *
from database.connections_mdb import active_connection

# Set up logging
logging.basicConfig(level=logging.ERROR)
logger = logging.getLogger(__name__)

TIMEZONE = "Asia/Kolkata"
BATCH_FILES = {}

@Client.on_message(filters.command("start") & filters.incoming)
async def start(client, message):
    if EMOJI_MODE:    
        await message.react(emoji=random.choice(REACTIONS), big=True) 
    if message.chat.type in [enums.ChatType.GROUP, enums.ChatType.SUPERGROUP]:
        buttons = [[
                    InlineKeyboardButton('• ᴀᴊᴏᴜᴛᴇᴢ-ᴍᴏɪ ᴀ ᴠᴏᴛʀᴇ ᴄʜᴀᴛ •', url=f'https://t.me/JessiKaPay')
                ],[
                    InlineKeyboardButton('• ᴘʀᴏᴘʀɪᴇᴛᴀɪʀᴇ •', url="https://t.me/cosmic_freak"),
                    InlineKeyboardButton('• ꜱᴜᴘᴘᴏʀᴛ •', url='https://t.me/codeflixsupport')
                ],[
                    InlineKeyboardButton('• ʀᴇᴊᴏɪɴᴅʀᴇ ʟᴇ ᴄᴀɴᴀʟ •', url="https://t.me/codeflix_bots")
                  ]]
        reply_markup = InlineKeyboardMarkup(buttons)
        await message.reply(script.GSTART_TXT.format(message.from_user.mention if message.from_user else message.chat.title, temp.U_NAME, temp.B_NAME), reply_markup=reply_markup, disable_web_page_preview=True)
        await asyncio.sleep(2) 
        if not await db.get_chat(message.chat.id):
            total=await client.get_chat_members_count(message.chat.id)
            await client.send_message(LOG_CHANNEL, script.LOG_TEXT_G.format(message.chat.title, message.chat.id, total, "Unknown"))       
            await db.add_chat(message.chat.id, message.chat.title)
        return 
    if not await db.is_user_exist(message.from_user.id):
        await db.add_user(message.from_user.id, message.from_user.first_name)
        await client.send_message(LOG_CHANNEL, script.LOG_TEXT_P.format(message.from_user.id, message.from_user.mention))
    if len(message.command) != 2:
        buttons = [[
                    InlineKeyboardButton(text="🏡", callback_data="start"),
                    InlineKeyboardButton(text="🛡", callback_data="group_info"),
                    InlineKeyboardButton(text="💳", callback_data="about"),
                    InlineKeyboardButton(text="🖥", callback_data="main"),
                ],[
                    InlineKeyboardButton('JessiKaPay', url=f'https://t.me/JessiKaPay')
                ],[
                    InlineKeyboardButton('• ᴄᴏᴍᴍᴀɴᴅᴇꜱ •', callback_data='main'),
                    InlineKeyboardButton('• ᴘʀᴇᴍɪᴜᴍ •', callback_data='premium_info'),
                    InlineKeyboardButton('• ᴀ ᴘʀᴏᴘᴏꜱ •', callback_data='about')
                  ]]
        reply_markup = InlineKeyboardMarkup(buttons)
        current_time = datetime.now(pytz.timezone(TIMEZONE))
        curr_time = current_time.hour        
        if curr_time < 12:
            gtxt = "ʙᴏɴᴊᴏᴜʀ 👋" 
        elif curr_time < 17:
            gtxt = "ʙᴏɴ ᴀᴘʀᴇꜱ-ᴍɪᴅɪ 👋" 
        elif curr_time < 21:
            gtxt = "ʙᴏɴꜱᴏɪʀ 👋"
        else:
            gtxt = "ʙᴏɴɴᴇ ɴᴜɪᴛ 👋"
        m=await message.reply_text("<i>ʙɪᴇɴᴠᴇɴᴜᴇ ᴄʜᴇᴢ <b>ʟᴜᴄʏ</b>.\nᴊ'ᴇꜱᴘᴇʀᴇ ǫᴜᴇ ᴠᴏᴜꜱ ᴀʟʟᴇᴢ ʙɪᴇɴ...</i>")
        await asyncio.sleep(0.4)
        await m.edit_text("⏳")
        await asyncio.sleep(0.5)
        await m.edit_text("👀")
        await asyncio.sleep(0.5)
        await m.edit_text("<b><i>ᴅᴇᴍᴀʀʀᴀɢᴇ...</i></b>")
        await asyncio.sleep(0.4)
        await m.delete()        
        m=await message.reply_sticker("CAACAgUAAxkBAAJFeWd037UWP-vgb_dWo55DCPZS9zJzAAJpEgACqXaJVxBrhzahNnwSHgQ") 
        await asyncio.sleep(1)
        await m.delete()
        await message.reply_photo(
            photo=random.choice(PICS),
            caption=script.START_TXT.format(message.from_user.mention, gtxt, temp.U_NAME, temp.B_NAME),
            reply_markup=reply_markup,
            parse_mode=enums.ParseMode.HTML
        )
        return
    
    if not await db.has_premium_access(message.from_user.id):
        channels = (await get_paramètres(int(message.from_user.id))).get('fsub')
        if channels:  
            btn = await is_subscribed(client, message, channels)
            if btn:
                kk, file_id = message.command[1].split("_", 1)
                btn.append([InlineKeyboardButton("ʀᴇᴇꜱꜱᴀʏᴇʀ", callback_data=f"checksub#{kk}#{file_id}")])
                reply_markup = InlineKeyboardMarkup(btn)
                caption = (
                    f"**ʀᴇᴊᴏɪɢɴᴇᴢ ɴᴏᴛʀᴇ ᴄᴀɴᴀʟ ᴅᴇ ᴍɪꜱᴇꜱ ᴀ ᴊᴏᴜʀ ᴘᴜɪꜱ ᴄʟɪǫᴜᴇᴢ ꜱᴜʀ ʀᴇᴇꜱꜱᴀʏᴇʀ ᴘᴏᴜʀ ᴏʙᴛᴇɴɪʀ ᴠᴏᴛʀᴇ ꜰɪᴄʜɪᴇʀ.**"
                )
                await message.reply_photo(
                    photo=random.choice(FSUB_PICS),
                    caption=caption,
                    reply_markup=reply_markup,
                    parse_mode=enums.ParseMode.HTML
                )
                return
       
    if len(message.command) == 2 and message.command[1] in ["subscribe", "error", "okay", "help"]:
        buttons = [[
                    InlineKeyboardButton(text="🏡", callback_data="start"),
                    InlineKeyboardButton(text="🛡", callback_data="group_info"),
                    InlineKeyboardButton(text="💳", callback_data="about"),
                    InlineKeyboardButton(text="🖥", callback_data="main"),
                ],[
                    InlineKeyboardButton('JessiKaPay', url=f'https://t.me/JessiKaPay')
                ],[
                    InlineKeyboardButton('• ᴄᴏᴍᴍᴀɴᴅᴇꜱ •', callback_data='main'),
                    InlineKeyboardButton('• ᴘʀᴇᴍɪᴜᴍ •', callback_data='premium_info'),
                    InlineKeyboardButton('• ᴀ ᴘʀᴏᴘᴏꜱ •', callback_data='about')
                  ]]
        reply_markup = InlineKeyboardMarkup(buttons)
        current_time = datetime.now(pytz.timezone(TIMEZONE))
        curr_time = current_time.hour        
        if curr_time < 12:
            gtxt = "ʙᴏɴᴊᴏᴜʀ 👋" 
        elif curr_time < 17:
            gtxt = "ʙᴏɴ ᴀᴘʀᴇꜱ-ᴍɪᴅɪ 👋" 
        elif curr_time < 21:
            gtxt = "ʙᴏɴꜱᴏɪʀ 👋"
        else:
            gtxt = "ʙᴏɴɴᴇ ɴᴜɪᴛ 👋"
        m=await message.reply_text("ꜱᴀʟᴜᴛ, ᴄᴏᴍᴍᴇɴᴛ ᴀʟʟᴇᴢ-ᴠᴏᴜꜱ \nᴘᴀᴛɪᴇɴᴛᴇᴢ ᴜɴ ɪɴꜱᴛᴀɴᴛ . . .")
        await asyncio.sleep(0.4)
        await m.edit_text("🎊")
        await asyncio.sleep(0.5)
        await m.edit_text("⚡")
        await asyncio.sleep(0.5)
        await m.edit_text("ᴅᴇᴍᴀʀʀᴀɢᴇ...")
        await asyncio.sleep(0.4)
        await m.delete()        
        m=await message.reply_sticker("CAACAgUAAxkBAAECroBmQKMAAQ-Gw4nibWoj_pJou2vP1a4AAlQIAAIzDxlVkNBkTEb1Lc4eBA") 
        await asyncio.sleep(1)
        await m.delete()
        await message.reply_photo(
            photo=random.choice(PICS),
            caption=script.START_TXT.format(message.from_user.mention, gtxt, temp.U_NAME, temp.B_NAME),
            reply_markup=reply_markup,
            parse_mode=enums.ParseMode.HTML
        )
        return
    if message.command[1].startswith("reff_"):
        try:
            user_id = int(message.command[1].split("_")[1])
        except ValueError:
            await message.reply_text("Parrainage invalide !")
            return
        if user_id == message.from_user.id:
            await message.reply_text("ꜱᴀʟᴜᴛ, ᴠᴏᴜꜱ ɴᴇ ᴘᴏᴜᴠᴇᴢ ᴘᴀꜱ ᴠᴏᴜꜱ ᴘᴀʀʀᴀɪɴᴇʀ ᴠᴏᴜꜱ-ᴍᴇᴍᴇ 🤣!\n\nᴘᴀʀᴛᴀɢᴇᴢ ʟᴇ ʟɪᴇɴ ᴀᴠᴇᴄ ᴠᴏꜱ ᴀᴍɪꜱ ᴇᴛ ɢᴀɢɴᴇᴢ 10 ᴘᴏɪɴᴛꜱ ᴅᴇ ᴘᴀʀʀᴀɪɴᴀɢᴇ. ᴀᴠᴇᴄ 100 ᴘᴏɪɴᴛꜱ ᴠᴏᴜꜱ ᴏʙᴛᴇɴᴇᴢ 1 ᴍᴏɪꜱ ᴅᴇ ᴘʀᴇᴍɪᴜᴍ ɢʀᴀᴛᴜɪᴛ.")
            return
        if referdb.is_user_in_list(message.from_user.id):
            await message.reply_text("ᴠᴏᴜꜱ ᴀᴠᴇᴢ ᴅᴇᴊᴀ ᴇᴛᴇ ɪɴᴠɪᴛᴇ ❗")
            return
        try:
            uss = await client.get_users(user_id)
        except Exception:
            return 	    
        referdb.add_user(message.from_user.id)
        fromuse = referdb.get_refer_points(user_id) + 10
        if fromuse == 100:
            referdb.add_refer_points(user_id, 0) 
            await message.reply_text(f"🎉 𝗙𝗲𝗹𝗶𝗰𝗶𝘁𝗮𝘁𝗶𝗼𝗻𝘀 ! 𝗩𝗼𝘂𝘀 𝗮𝘃𝗲𝘇 𝗴𝗮𝗴𝗻𝗲 𝟭𝟬 𝗽𝗼𝗶𝗻𝘁𝘀 𝗱𝗲 𝗽𝗮𝗿𝗿𝗮𝗶𝗻𝗮𝗴𝗲 𝗰𝗮𝗿 𝘃𝗼𝘂𝘀 𝗮𝘃𝗲𝘇 𝗶𝗻𝘃𝗶𝘁𝗲 𝗮𝘃𝗲𝗰 𝘀𝘂𝗰𝗰𝗲𝘀 ☞ {uss.mention}!")		    
            await message.reply_text(user_id, f"Vous avez été invité par {message.from_user.mention}!") 	
            seconds = 2592000
            if seconds > 0:
                expiry_time = datetime.datetime.now() + datetime.timedelta(seconds=seconds)
                user_data = {"id": user_id, "expiry_time": expiry_time}  # Using "id" instead of "user_id"  
                await db.update_user(user_data)  # Use the update_user method to update or insert user data		    
                await client.send_message(
                chat_id=user_id,
                text=f"<b>Hᴇʏ {uss.mention}\n\nᴠᴏᴜꜱ ᴀᴠᴇᴢ ᴏʙᴛᴇɴᴜ 1 ᴍᴏɪꜱ ᴅᴇ ᴘʀᴇᴍɪᴜᴍ ᴇɴ ɪɴᴠɪᴛᴀɴᴛ 10 ᴜᴛɪʟɪꜱᴀᴛᴇᴜʀꜱ ❗", disable_web_page_preview=True              
                )
            for admin in ADMINS:
                await client.send_message(chat_id=admin, text=f"ᴛᴀᴄʜᴇ ᴄᴏᴍᴘʟᴇᴛᴇᴇ ᴀᴠᴇᴄ ꜱᴜᴄᴄᴇꜱ ᴘᴀʀ ᴄᴇᴛ ᴜᴛɪʟɪꜱᴀᴛᴇᴜʀ :\n\nuser ɴᴏᴍ: {uss.mention}\n\nɪᴅ ᴜᴛɪʟɪꜱᴀᴛᴇᴜʀ : {uss.id}!")	
        else:
            referdb.add_refer_points(user_id, fromuse)
            await message.reply_text(f"Vous avez été invité par {uss.mention}!")
            await client.send_message(user_id, f"𝗙𝗲𝗹𝗶𝗰𝗶𝘁𝗮𝘁𝗶𝗼𝗻𝘀 ! 𝗩𝗼𝘂𝘀 𝗮𝘃𝗲𝘇 𝗴𝗮𝗴𝗻𝗲 𝟭𝟬 𝗽𝗼𝗶𝗻𝘁𝘀 𝗱𝗲 𝗽𝗮𝗿𝗿𝗮𝗶𝗻𝗮𝗴𝗲 𝗰𝗮𝗿 𝘃𝗼𝘂𝘀 𝗮𝘃𝗲𝘇 𝗶𝗻𝘃𝗶𝘁𝗲 𝗮𝘃𝗲𝗰 𝘀𝘂𝗰𝗰𝗲𝘀 ☞{message.from_user.mention}!")
        return
        
    if len(message.command) == 2 and message.command[1] in ["premium"]:
        buttons = [[
                    InlineKeyboardButton('📲 ᴇɴᴠᴏʏᴇʀ ʟᴀ ᴄᴀᴘᴛᴜʀᴇ ᴅᴜ ᴘᴀɪᴇᴍᴇɴᴛ', url=OWNER_LNK)
                  ],[
                    InlineKeyboardButton('❌ ꜰᴇʀᴍᴇʀ ❌', callback_data='close_data')
                  ]]
        reply_markup = InlineKeyboardMarkup(buttons)
        await message.reply_photo(
            photo=(SUBSCRIPTION),
            caption=script.PREPLANS_TXT.format(message.from_user.mention, OWNER_UPI_ID, QR_CODE),
            reply_markup=reply_markup,
            parse_mode=enums.ParseMode.HTML
        )
        return  
    if len(message.command) == 2 and message.command[1].startswith('getfile'):
        movies = message.command[1].split("-", 1)[1] 
        movie = movies.replace('-',' ')
        message.text = movie 
        await auto_filter(client, message) 
        return
    
    data = message.command[1]
    try:
        pre, file_id = data.split('_', 1)
    except:
        file_id = data
        pre = ""

    if data.split("-", 1)[0] == "BATCH":
        sts = await message.reply("<b>Veuillez patienter...</b>")
        file_id = data.split("-", 1)[1]
        msgs = BATCH_FILES.get(file_id)
        if not msgs:
            file = await client.download_media(file_id)
            try:
                with open(file) as file_data:
                    msgs = json.loads(file_data.read())
            except:
                await sts.edit("ECHEC")
                return await client.send_message(LOG_CHANNEL, "IMPOSSIBLE D'OUVRIR LE FICHIER.")
            os.remove(file)
            BATCH_FILES[file_id] = msgs

        for msg in msgs:
            title = msg.get("title")
            size = get_size(int(msg.get("size", 0)))
            f_caption = msg.get("caption", "")

            if BATCH_FILE_CAPTION:
                try:
                    f_caption = BATCH_FILE_CAPTION.format(file_name='' if title is None else title, file_size='' if size is None else size, file_caption='' if f_caption is None else f_caption)
                except Exception as e:
                    logger.exception(e)
                    f_caption = f_caption

            if f_caption is None:
                f_caption = f"{title}"

            if STREAM_MODE:
                btn = [
                    [InlineKeyboardButton('🚀 ᴛᴇʟᴇᴄʜᴀʀɢᴇᴍᴇɴᴛ ʀᴀᴘɪᴅᴇ / ʀᴇɢᴀʀᴅᴇʀ ᴇɴ ʟɪɢɴᴇ 🖥️', callback_data=f'generate_stream_link:{file_id}')],
                    [InlineKeyboardButton('📌 ʀᴇᴊᴏɪɴᴅʀᴇ ʟᴇ ᴄᴀɴᴀʟ 📌', url=MOVIE_UPDATE_CHANNEL_LNK)]  # Keep this line unchanged
                ]
            else:
                btn = [
                    [InlineKeyboardButton('📌 ʀᴇᴊᴏɪɴᴅʀᴇ ʟᴇ ᴄᴀɴᴀʟ 📌', url=MOVIE_UPDATE_CHANNEL_LNK)]
                ]
            try:
                await client.send_cached_media(
                    chat_id=message.from_user.id,
                    file_id=msg.get("file_id"),
                    caption=f_caption,
                    protect_content=msg.get('protect', False),
                    reply_markup=InlineKeyboardMarkup(btn)
                )
            except FloodWait as e:
                await asyncio.sleep(e.x)
                logger.warning(f"Floodwait of {e.x} sec.")
                await client.send_cached_media(
                    chat_id=message.from_user.id,
                    file_id=msg.get("file_id"),
                    caption=f_caption,
                    protect_content=msg.get('protect', False),
                    reply_markup=InlineKeyboardMarkup(btn)
                )
            except Exception as e:
                logger.warning(e, exc_info=True)
                continue
            await asyncio.sleep(1)

        await sts.delete()
        return


    elif data.split("-", 1)[0] == "DSTORE":
        sts = await message.reply("<b>Veuillez patienter...</b>")
        b_string = data.split("-", 1)[1]
        decoded = (base64.urlsafe_b64decode(b_string + "=" * (-len(b_string) % 4))).decode("ascii")
        try:
            f_msg_id, l_msg_id, f_chat_id, protect = decoded.split("_", 3)
        except:
            f_msg_id, l_msg_id, f_chat_id = decoded.split("_", 2)
            protect = "/pbatch" if PROTECT_CONTENT else "batch"
        diff = int(l_msg_id) - int(f_msg_id)
        async for msg in client.iter_messages(int(f_chat_id), int(l_msg_id), int(f_msg_id)):
            if msg.media:
                media = getattr(msg, msg.media.value)
                if BATCH_FILE_CAPTION:
                    try:
                        f_caption=BATCH_FILE_CAPTION.format(file_name=getattr(media, 'file_name', ''), file_size=getattr(media, 'file_size', ''), file_caption=getattr(msg, 'caption', ''))
                    except Exception as e:
                        logger.exception(e)
                        f_caption = getattr(msg, 'caption', '')
                else:
                    media = getattr(msg, msg.media.value)
                    file_name = getattr(media, 'file_name', '')
                    f_caption = getattr(msg, 'caption', file_name)
                try:
                    await msg.copy(message.chat.id, caption=f_caption, protect_content=True if protect == "/pbatch" else False)
                except FloodWait as e:
                    await asyncio.sleep(e.x)
                    await msg.copy(message.chat.id, caption=f_caption, protect_content=True if protect == "/pbatch" else False)
                except Exception as e:
                    logger.exception(e)
                    continue
            elif msg.empty:
                continue
            else:
                try:
                    await msg.copy(message.chat.id, protect_content=True if protect == "/pbatch" else False)
                except FloodWait as e:
                    await asyncio.sleep(e.x)
                    await msg.copy(message.chat.id, protect_content=True if protect == "/pbatch" else False)
                except Exception as e:
                    logger.exception(e)
                    continue
            await asyncio.sleep(1) 
        return await sts.delete()

    elif data.split("-", 1)[0] == "verify":
        userid = data.split("-", 2)[1]
        token = data.split("-", 3)[2] 
        fileid = data.split("-", 3)[3]
        if str(message.from_user.id) != str(userid):
            return await message.reply_text(
                text="<b>Lien invalide ou expiré !</b>",
                protect_content=False
            )
        is_valid = await check_token(client, userid, token)
        if is_valid == True:
            btn = [[
                InlineKeyboardButton("ᴄʟɪǫᴜᴇᴢ ɪᴄɪ ᴘᴏᴜʀ ᴏʙᴛᴇɴɪʀ ʟᴇ ꜰɪᴄʜɪᴇʀ", url=f"https://telegram.me/{temp.U_NAME}?start=files_{fileid}")
            ]]
            await message.reply_photo(
                photo="https://graph.org/file/6928de1539e2e80e47fb8.jpg",
                caption=f"<blockquote><b>👋 ʜᴇʏ {message.from_user.mention}, ᴠᴏᴜꜱ ᴇᴛᴇꜱ ᴠᴇʀɪꜰɪᴇ ᴀᴠᴇᴄ ꜱᴜᴄᴄᴇꜱ ✅\n\nᴠᴏᴜꜱ ᴀᴠᴇᴢ ᴜɴ ᴀᴄᴄᴇꜱ ɪʟʟɪᴍɪᴛᴇ ᴘᴏᴜʀ {VERIFY_EXPIRE} ʜᴇᴜʀᴇꜱ🎉</blockquote></b>",
                reply_markup=InlineKeyboardMarkup(btn)
            )
            await verify_user(client, userid, token) 
            await vr_db.save_verification(message.from_user.id) 
            now = datetime.now()
            current_time = now.strftime("%H:%M:%S")
            current_date = now.strftime("%Y-%m-%d")
            
            lucy_message = (
                f"Nom : {message.from_user.mention}\n"
                f"Heure : {current_time}\n"
                f"Date : {current_date}\n"
                f"#verify_completed"
            )
            await client.send_message(chat_id=VERIFIED_LOG, text=lucy_message)

        else:
            return await message.reply_text(
                text="<b>Lien invalide ou expiré !</b>",
                protect_content=False
            )
    if data.startswith("sendfiles"):
        # Shortlink supprimé — redirige directement vers allfiles
        return await message.reply_text("<b>Veuillez utiliser le bouton de résultat directement dans le groupe.</b>")

    elif data.startswith("short"):
        # Shortlink supprimé — redirige vers file_
        pass

    elif data.startswith("all"):
        files = temp.GETALL.get(file_id)
        if not files:
            return await message.reply('<b><i>ᴄᴇ ꜰɪᴄʜɪᴇʀ ɴ\'ᴇxɪꜱᴛᴇ ᴘᴀꜱ !</b></i>')
        filesarr = []
        for file in files:
            file_id = file.file_id
            files_ = await get_file_details(file_id)
            files1 = files_[0]
            title = ' '.join(filter(lambda x: not x.startswith('[') and not x.startswith('@') and not x.startswith('www.'), files1.file_name.split()))
            size = get_size(files1.file_size)
            f_caption = files1.caption

            if CUSTOM_FILE_CAPTION:
                try:
                    f_caption=CUSTOM_FILE_CAPTION.format(file_name= '' if title is None else title, file_size='' if size is None else size, file_caption='' if f_caption is None else f_caption)
                except Exception as e:
                    logger.exception(e)
                    f_caption = f_caption

            if f_caption is None:
                f_caption = f"{' '.join(filter(lambda x: not x.startswith('[') and not x.startswith('@') and not x.startswith('www.'), files1.file_name.split()))}"
            from database.jks_db import get_user_access
            from info import MINI_APP_URL
            _access = await get_user_access(message.from_user.id)
            if not _access["has_access"]:
                btn = [[
                    InlineKeyboardButton("📺 ꜱᴇꜱꜱɪᴏɴ ɢʀᴀᴛᴜɪᴛᴇ — ʀᴇɢᴀʀᴅᴇᴢ ᴜɴᴇ ᴘᴜʙ ᴘᴏᴜʀ 1ʜ ᴅ'ᴀᴄᴄᴇꜱ", web_app={"url": f"{MINI_APP_URL}?tab=access"})
                ],[
                    InlineKeyboardButton("💎 ꜱᴏᴜꜱᴄʀɪʀᴇ ᴀᴜ ᴘʀᴇᴍɪᴜᴍ", web_app={"url": f"{MINI_APP_URL}?tab=premium"})
                ]]
                l = await message.reply_text(
                    text=(
                        "<blockquote><b>⚠️ ᴀᴄᴄᴇꜱ ʀᴇǫᴜɪꜱ</b></blockquote>\n\n"
                        "ᴠᴏᴜꜱ ꜱᴏᴜʜᴀɪᴛᴇᴢ ʀᴇᴄᴜᴘᴇʀᴇʀ ᴜɴ ꜰɪᴄʜɪᴇʀ, ᴍᴀɪꜱ ᴠᴏᴜꜱ ɴ'ᴀᴠᴇᴢ ᴘᴀꜱ ᴅᴇ ꜱᴇꜱꜱɪᴏɴ ᴀᴄᴛɪᴠᴇ.\n\n"
                        "ᴄʜᴏɪꜱɪꜱꜱᴇᴢ ᴜɴᴇ ᴏᴘᴛɪᴏɴ :\n\n"
                        "📺 <b>ꜱᴇꜱꜱɪᴏɴ ɢʀᴀᴛᴜɪᴛᴇ</b> — ʀᴇɢᴀʀᴅᴇᴢ ᴜɴᴇ ᴘᴜʙ ᴇᴛ ᴏʙᴛᴇɴᴇᴢ <b>1ʜ ᴅ'ᴀᴄᴄᴇꜱ</b> ᴀ ᴛᴏᴜꜱ ʟᴇꜱ ꜰɪᴄʜɪᴇʀꜱ.\n\n"
                        "💎 <b>ᴘʀᴇᴍɪᴜᴍ</b> — ᴀᴄᴄᴇꜱ ɪʟʟɪᴍɪᴛᴇ ꜱᴀɴꜱ ᴘᴜʙ, ᴅᴇ 7 ᴊᴏᴜʀꜱ ᴀ 1 ᴀɴ."
                    ),
                    protect_content=False,
                    reply_markup=InlineKeyboardMarkup(btn)
                )
                await asyncio.sleep(300)
                await l.delete()
                return
            if STREAM_MODE:
                btn = [
                    [InlineKeyboardButton('🚀 ᴛᴇʟᴇᴄʜᴀʀɢᴇᴍᴇɴᴛ ʀᴀᴘɪᴅᴇ / ʀᴇɢᴀʀᴅᴇʀ ᴇɴ ʟɪɢɴᴇ 🖥️', callback_data=f'generate_stream_link:{file_id}')],
                    [InlineKeyboardButton('📌 ʀᴇᴊᴏɪɴᴅʀᴇ ʟᴇ ᴄᴀɴᴀʟ 📌', url=MOVIE_UPDATE_CHANNEL_LNK)]  # Keep this line unchanged  
                ]
            else:
                btn = [
                    [InlineKeyboardButton('📌 ʀᴇᴊᴏɪɴᴅʀᴇ ʟᴇ ᴄᴀɴᴀʟ 📌', url=MOVIE_UPDATE_CHANNEL_LNK)]
                ]

            msg = await client.send_cached_media(
                chat_id=message.from_user.id,
                file_id=file_id,
                caption=f_caption,
                protect_content=True if pre == 'filep' else False,
                reply_markup=InlineKeyboardMarkup(btn)
            )
            filesarr.append(msg)
        k = await client.send_message(chat_id=message.from_user.id, text=f"<b><u>❗️❗️❗️IMPORTANT❗️️❗️❗️</u></b>\n\nᴄᴇ ꜰɪᴄʜɪᴇʀ/ᴠɪᴅᴇᴏ ꜱᴇʀᴀ ꜱᴜᴘᴘʀɪᴍᴇ ᴅᴀɴꜱ <b><u><code>{get_time(DELETE_TIME)}</code></u> 🫥 <i></b>(ᴘᴏᴜʀ ᴅᴇꜱ ʀᴀɪꜱᴏɴꜱ ᴅᴇ ᴅʀᴏɪᴛꜱ ᴅ'ᴀᴜᴛᴇᴜʀ)</i>.\n\n<b><i>ᴠᴇᴜɪʟʟᴇᴢ ᴛʀᴀɴꜱꜰᴇʀᴇʀ ᴄᴇ ꜰɪᴄʜɪᴇʀ ᴀɪʟʟᴇᴜʀꜱ ᴇᴛ ᴛᴇʟᴇᴄʜᴀʀɢᴇᴢ-ʟᴇ ʟᴀ-ʙᴀꜱ</i></b>")
        await asyncio.sleep(DELETE_TIME)
        for x in filesarr:
            await x.delete()
        await k.edit_text("<b>ʏᴏᴜʀ ᴀʟʟ ᴠɪᴅᴇᴏꜱ/ꜰɪʟᴇꜱ ᴀʀᴇ ᴅᴇʟᴇᴛᴇᴅ ꜱᴜᴄᴄᴇꜱꜱꜰᴜʟʟʏ !\nᴋɪɴᴅʟʏ ʀᴇᴄʜᴇʀᴄʜᴇ ᴀɢᴀɪɴ</b>")
        return
    elif data.startswith("files"):
        # Shortlink supprimé — on redirige directement vers file_
        # file_id est déjà parsé plus haut, on laisse tomber dans le handler principal
        pass
    user = message.from_user.id
    files_ = await get_file_details(file_id)        
    if not files_:
        pre, file_id = ((base64.urlsafe_b64decode(data + "=" * (-len(data) % 4))).decode("ascii")).split("_", 1)
        try:
            from database.jks_db import get_user_access
            from info import MINI_APP_URL
            _access = await get_user_access(message.from_user.id)
            if not _access["has_access"]:
                btn = [[
                    InlineKeyboardButton("📺 ꜱᴇꜱꜱɪᴏɴ ɢʀᴀᴛᴜɪᴛᴇ — ʀᴇɢᴀʀᴅᴇᴢ ᴜɴᴇ ᴘᴜʙ ᴘᴏᴜʀ 1ʜ ᴅ'ᴀᴄᴄᴇꜱ", web_app={"url": f"{MINI_APP_URL}?tab=access"})
                ],[
                    InlineKeyboardButton("💎 ꜱᴏᴜꜱᴄʀɪʀᴇ ᴀᴜ ᴘʀᴇᴍɪᴜᴍ", web_app={"url": f"{MINI_APP_URL}?tab=premium"})
                ]]
                l = await message.reply_text(
                    text=(
                        "<blockquote><b>⚠️ ᴀᴄᴄᴇꜱ ʀᴇǫᴜɪꜱ</b></blockquote>\n\n"
                        "ᴠᴏᴜꜱ ꜱᴏᴜʜᴀɪᴛᴇᴢ ʀᴇᴄᴜᴘᴇʀᴇʀ ᴜɴ ꜰɪᴄʜɪᴇʀ, ᴍᴀɪꜱ ᴠᴏᴜꜱ ɴ'ᴀᴠᴇᴢ ᴘᴀꜱ ᴅᴇ ꜱᴇꜱꜱɪᴏɴ ᴀᴄᴛɪᴠᴇ.\n\n"
                        "ᴄʜᴏɪꜱɪꜱꜱᴇᴢ ᴜɴᴇ ᴏᴘᴛɪᴏɴ :\n\n"
                        "📺 <b>ꜱᴇꜱꜱɪᴏɴ ɢʀᴀᴛᴜɪᴛᴇ</b> — ʀᴇɢᴀʀᴅᴇᴢ ᴜɴᴇ ᴘᴜʙ ᴇᴛ ᴏʙᴛᴇɴᴇᴢ <b>1ʜ ᴅ'ᴀᴄᴄᴇꜱ</b> ᴀ ᴛᴏᴜꜱ ʟᴇꜱ ꜰɪᴄʜɪᴇʀꜱ.\n\n"
                        "💎 <b>ᴘʀᴇᴍɪᴜᴍ</b> — ᴀᴄᴄᴇꜱ ɪʟʟɪᴍɪᴛᴇ ꜱᴀɴꜱ ᴘᴜʙ, ᴅᴇ 7 ᴊᴏᴜʀꜱ ᴀ 1 ᴀɴ."
                    ),
                    protect_content=False,
                    reply_markup=InlineKeyboardMarkup(btn)
                )
                await asyncio.sleep(300)
                await l.delete()
                return
            if STREAM_MODE:
                btn = [
                    [InlineKeyboardButton('🚀 ᴛᴇʟᴇᴄʜᴀʀɢᴇᴍᴇɴᴛ ʀᴀᴘɪᴅᴇ / ʀᴇɢᴀʀᴅᴇʀ ᴇɴ ʟɪɢɴᴇ 🖥️', callback_data=f'generate_stream_link:{file_id}')],
                    [InlineKeyboardButton('📌 ʀᴇᴊᴏɪɴᴅʀᴇ ʟᴇ ᴄᴀɴᴀʟ 📌', url=MOVIE_UPDATE_CHANNEL_LNK)]  # Keep this line unchanged
             
                ]
            else:
                btn = [
                    [InlineKeyboardButton('📌 ʀᴇᴊᴏɪɴᴅʀᴇ ʟᴇ ᴄᴀɴᴀʟ 📌', url=MOVIE_UPDATE_CHANNEL_LNK)]
                ]
            msg = await client.send_cached_media(
                chat_id=message.from_user.id,
                file_id=file_id,
                protect_content=True if pre == 'filep' else False,
                reply_markup=InlineKeyboardMarkup(btn))

            filetype = msg.media
            file = getattr(msg, filetype.value)
            title = ' '.join(filter(lambda x: not x.startswith('[') and not x.startswith('@') and not x.startswith('www.'), file.file_name.split()))
            size=get_size(file.file_size)
            f_caption = f"<code>{title}</code>"
            if CUSTOM_FILE_CAPTION:
                try:
                    f_caption=CUSTOM_FILE_CAPTION.format(file_name= '' if title is None else title, file_size='' if size is None else size, file_caption='')
                except:
                    return
            await msg.edit_caption(f_caption)
            btn = [[
                InlineKeyboardButton("❗ ʀᴇᴏʙᴛᴇɴɪʀ ʟᴇ ꜰɪᴄʜɪᴇʀ ❗", callback_data=f'delfile#{file_id}')
            ]]
            k = await msg.reply(
                f"<b><u>⚠️ ɪɴꜰᴏʀᴍᴀᴛɪᴏɴ ɪᴍᴘᴏʀᴛᴀɴᴛᴇ ⚠️</u></b>\n\n"
                f"ᴄᴇ ꜰɪᴄʜɪᴇʀ/ᴠɪᴅᴇᴏ ꜱᴇʀᴀ ꜱᴜᴘᴘʀɪᴍᴇ ᴅᴀɴꜱ <b><u><code>{get_time(DELETE_TIME)}</code></u> 🫥 <i></b>"
                "(ᴘᴏᴜʀ ᴅᴇꜱ ʀᴀɪꜱᴏɴꜱ ᴅᴇ ᴅʀᴏɪᴛꜱ ᴅ'ᴀᴜᴛᴇᴜʀ)</i>.\n\n"
                "<b><i>ᴠᴇᴜɪʟʟᴇᴢ ᴛʀᴀɴꜱꜰᴇʀᴇʀ ᴄᴇ ꜰɪᴄʜɪᴇʀ ᴀɪʟʟᴇᴜʀꜱ ᴇᴛ ᴛᴇʟᴇᴄʜᴀʀɢᴇᴢ-ʟᴇ ʟᴀ-ʙᴀꜱ</i></b>",
                quote=True
            )
            await asyncio.sleep(DELETE_TIME)
            await msg.delete()
            await k.edit_text("<b>ᴠᴏᴛʀᴇ ꜰɪᴄʜɪᴇʀ / ᴠɪᴅᴇᴏ ᴀ ᴇᴛᴇ ꜱᴜᴘᴘʀɪᴍᴇ !</b>")
            return
        except:
            pass
        return await message.reply('<b>ᴄᴇ ꜰɪᴄʜɪᴇʀ ɴ\'ᴇxɪꜱᴛᴇ ᴘᴀꜱ !</b>')
    
    files = files_[0]
    title = ' '.join(filter(lambda x: not x.startswith('[') and not x.startswith('@') and not x.startswith('www.'), files.file_name.split()))
    size = get_size(files.file_size)
    f_caption = files.caption

    if CUSTOM_FILE_CAPTION:
        try:
            f_caption=CUSTOM_FILE_CAPTION.format(file_name= '' if title is None else title, file_size='' if size is None else size, file_caption='' if f_caption is None else f_caption)
        except Exception as e:
            logger.exception(e)
            f_caption = f_caption

    if f_caption is None:
        f_caption = ' '.join(filter(lambda x: not x.startswith('[') and not x.startswith('@') and not x.startswith('www.'), files.file_name.split()))

    from database.jks_db import get_user_access
    from info import MINI_APP_URL
    _access = await get_user_access(message.from_user.id)
    if not _access["has_access"]:
        btn = [[
            InlineKeyboardButton("📺 ꜱᴇꜱꜱɪᴏɴ ɢʀᴀᴛᴜɪᴛᴇ — ʀᴇɢᴀʀᴅᴇᴢ ᴜɴᴇ ᴘᴜʙ ᴘᴏᴜʀ 1ʜ ᴅ'ᴀᴄᴄᴇꜱ", web_app={"url": f"{MINI_APP_URL}?tab=access"})
        ],[
            InlineKeyboardButton("💎 ꜱᴏᴜꜱᴄʀɪʀᴇ ᴀᴜ ᴘʀᴇᴍɪᴜᴍ", web_app={"url": f"{MINI_APP_URL}?tab=premium"})
        ]]
        l = await message.reply_text(
            text=(
                "<blockquote><b>⚠️ ᴀᴄᴄᴇꜱ ʀᴇǫᴜɪꜱ</b></blockquote>\n\n"
                "ᴠᴏᴜꜱ ꜱᴏᴜʜᴀɪᴛᴇᴢ ʀᴇᴄᴜᴘᴇʀᴇʀ ᴜɴ ꜰɪᴄʜɪᴇʀ, ᴍᴀɪꜱ ᴠᴏᴜꜱ ɴ'ᴀᴠᴇᴢ ᴘᴀꜱ ᴅᴇ ꜱᴇꜱꜱɪᴏɴ ᴀᴄᴛɪᴠᴇ.\n\n"
                "ᴄʜᴏɪꜱɪꜱꜱᴇᴢ ᴜɴᴇ ᴏᴘᴛɪᴏɴ :\n\n"
                "📺 <b>ꜱᴇꜱꜱɪᴏɴ ɢʀᴀᴛᴜɪᴛᴇ</b> — ʀᴇɢᴀʀᴅᴇᴢ ᴜɴᴇ ᴘᴜʙ ᴇᴛ ᴏʙᴛᴇɴᴇᴢ <b>1ʜ ᴅ'ᴀᴄᴄᴇꜱ</b> ᴀ ᴛᴏᴜꜱ ʟᴇꜱ ꜰɪᴄʜɪᴇʀꜱ.\n\n"
                "💎 <b>ᴘʀᴇᴍɪᴜᴍ</b> — ᴀᴄᴄᴇꜱ ɪʟʟɪᴍɪᴛᴇ ꜱᴀɴꜱ ᴘᴜʙ, ᴅᴇ 7 ᴊᴏᴜʀꜱ ᴀ 1 ᴀɴ."
            ),
            protect_content=False,
            reply_markup=InlineKeyboardMarkup(btn)
        )
        await asyncio.sleep(300)
        await l.delete()
        return
    if STREAM_MODE:
        btn = [
            [InlineKeyboardButton('🚀 ᴛᴇʟᴇᴄʜᴀʀɢᴇᴍᴇɴᴛ ʀᴀᴘɪᴅᴇ / ʀᴇɢᴀʀᴅᴇʀ ᴇɴ ʟɪɢɴᴇ 🖥️', callback_data=f'generate_stream_link:{file_id}')],
            [InlineKeyboardButton('📌 ʀᴇᴊᴏɪɴᴅʀᴇ ʟᴇ ᴄᴀɴᴀʟ 📌', url=MOVIE_UPDATE_CHANNEL_LNK)]  # Keep this line unchanged
        ]
    else:
        btn = [
            [InlineKeyboardButton('📌 ʀᴇᴊᴏɪɴᴅʀᴇ ʟᴇ ᴄᴀɴᴀʟ 📌', url=MOVIE_UPDATE_CHANNEL_LNK)]
        ]
    msg = await client.send_cached_media(
        chat_id=message.from_user.id,
        file_id=file_id,
        caption=f_caption,
        protect_content=True if pre == 'filep' else False,
        reply_markup=InlineKeyboardMarkup(btn)
    )
    btn = [[
            InlineKeyboardButton("❗ ʀᴇᴏʙᴛᴇɴɪʀ ʟᴇ ꜰɪᴄʜɪᴇʀ ❗", callback_data=f'delfile#{file_id}')
        ]]
    k = await msg.reply(
        f"<b><u>⚠️ ɪɴꜰᴏʀᴍᴀᴛɪᴏɴ ɪᴍᴘᴏʀᴛᴀɴᴛᴇ ⚠️</u></b>\n\n"
        f"ᴄᴇ ꜰɪᴄʜɪᴇʀ/ᴠɪᴅᴇᴏ ꜱᴇʀᴀ ꜱᴜᴘᴘʀɪᴍᴇ ᴅᴀɴꜱ <b><u><code>{get_time(DELETE_TIME)}</code></u> 🫥 <i></b>"
        "(ᴘᴏᴜʀ ᴅᴇꜱ ʀᴀɪꜱᴏɴꜱ ᴅᴇ ᴅʀᴏɪᴛꜱ ᴅ'ᴀᴜᴛᴇᴜʀ)</i>.\n\n"
        "<b><i>ᴠᴇᴜɪʟʟᴇᴢ ᴛʀᴀɴꜱꜰᴇʀᴇʀ ᴄᴇ ꜰɪᴄʜɪᴇʀ ᴀɪʟʟᴇᴜʀꜱ ᴇᴛ ᴛᴇʟᴇᴄʜᴀʀɢᴇᴢ-ʟᴇ ʟᴀ-ʙᴀꜱ</i></b>",
        quote=True
    )     
    await asyncio.sleep(DELETE_TIME)
    await msg.delete()
    await k.edit_text("<b>ᴠᴏᴛʀᴇ ꜰɪᴄʜɪᴇʀ / ᴠɪᴅᴇᴏ ᴀ ᴇᴛᴇ ꜱᴜᴘᴘʀɪᴍᴇ !</b>")
    return


@Client.on_message(filters.command('channel') & filters.user(ADMINS))
async def channel_info(bot, message):
           
    """Send basic information of channel"""
    if isinstance(CHANNELS, (int, str)):
        channels = [CHANNELS]
    elif isinstance(CHANNELS, list):
        channels = CHANNELS
    else:
        raise ValueError("ᴛʏᴘᴇ ᴅᴇ ᴄᴀɴᴀʟ ɪɴᴄᴏɴɴᴜ.")

    text = '📑 **ꜱᴇʀᴠᴇᴜʀꜱ ᴇᴛ ɢʀᴏᴜᴘᴇꜱ ɪɴᴅᴇxᴇꜱ :**\n'
    for channel in channels:
        chat = await bot.get_chat(channel)
        if chat.username:
            text += '\n@' + chat.username
        else:
            text += '\n' + chat.title or chat.first_name

    text += f'\n\n**ᴛᴏᴛᴀʟ :** {len(CHANNELS)}'

    if len(text) < 4096:
        await message.reply(text)
    else:
        file = 'Indexé channels.txt'
        with open(file, 'w') as f:
            f.write(text)
        await message.reply_document(file)
        os.remove(file)


@Client.on_message(filters.command('logs') & filters.user(ADMINS))
async def log_file(bot, message):
    """Send log file"""
    try:
        await message.reply_document('TELEGRAM BOT.LOG')
    except Exception as e:
        await message.reply(str(e))

@Client.on_message(filters.command('delete') & filters.user(ADMINS))
async def delete(bot, message):
    """Delete file from database"""
    reply = message.reply_to_message
    if reply and reply.media:
        msg = await message.reply("Pʀᴏᴄᴇssɪɴɢ...⏳", quote=True)
    else:
        await message.reply('Rᴇᴘʟʏ ᴛᴏ ғɪʟᴇ ᴡɪᴛʜ /delete ᴡʜɪᴄʜ ʏᴏᴜ ᴡᴀɴᴛ ᴛᴏ ᴅᴇʟᴇᴛᴇ', quote=True)
        return

    for file_type in ("document", "video", "audio"):
        media = getattr(reply, file_type, None)
        if media is not None:
            break
    else:
        await msg.edit('ᴄᴇ ꜰᴏʀᴍᴀᴛ ᴅᴇ ꜰɪᴄʜɪᴇʀ ɴ\'ᴇꜱᴛ ᴘᴀꜱ ꜱᴜᴘᴘᴏʀᴛᴇ')
        return
    
    file_id, file_ref = unpack_new_file_id(media.file_id)
    if await Media.count_documents({'file_id': file_id}):
        result = await Media.collection.delete_one({
            '_id': file_id,
        })
    else:
        result = await Media2.collection.delete_one({
            '_id': file_id,
        })
    if result.deleted_count:
        await msg.edit('Fɪʟᴇ ɪs sᴜᴄᴄᴇssғᴜʟʟʏ ᴅᴇʟᴇᴛᴇᴅ ғʀᴏᴍ ᴅᴀᴛᴀʙᴀsᴇ ✅')
    else:
        file_name = re.sub(r"(_|\-|\.|\+)", " ", str(media.file_name))
        result = await Media.collection.delete_many({
            'file_name': file_name,
            'file_size': media.file_size,
            'mime_type': media.mime_type
            })
        if result.deleted_count:
            await msg.edit('Fɪʟᴇ ɪs sᴜᴄᴄᴇssғᴜʟʟʏ ᴅᴇʟᴇᴛᴇᴅ ғʀᴏᴍ ᴅᴀᴛᴀʙᴀsᴇ ✅')
        else:
            result = await Media2.collection.delete_many({
                'file_name': file_name,
                'file_size': media.file_size,
                'mime_type': media.mime_type
            })
            if result.deleted_count:
                await msg.edit('Fɪʟᴇ ɪs sᴜᴄᴄᴇssғᴜʟʟʏ ᴅᴇʟᴇᴛᴇᴅ ғʀᴏᴍ ᴅᴀᴛᴀʙᴀsᴇ')
            else:
                result = await Media.collection.delete_many({
                    'file_name': media.file_name,
                    'file_size': media.file_size,
                    'mime_type': media.mime_type
                })
                if result.deleted_count:
                    await msg.edit('Fɪʟᴇ ɪs sᴜᴄᴄᴇssғᴜʟʟʏ ᴅᴇʟᴇᴛᴇᴅ ғʀᴏᴍ ᴅᴀᴛᴀʙᴀsᴇ ✅')
                else:
                    result = await Media2.collection.delete_many({
                        'file_name': media.file_name,
                        'file_size': media.file_size,
                        'mime_type': media.mime_type
                    })
                    if result.deleted_count:
                        await msg.edit('Fɪʟᴇ ɪs sᴜᴄᴄᴇssғᴜʟʟʏ ᴅᴇʟᴇᴛᴇᴅ ғʀᴏᴍ ᴅᴀᴛᴀʙᴀsᴇ ✅')
                    else:
                        await msg.edit('Fɪʟᴇ ɴᴏᴛ ғᴏᴜɴᴅ ɪɴ ᴅᴀᴛᴀʙᴀsᴇ ❌')


@Client.on_message(filters.command('deleteall') & filters.user(ADMINS))
async def delete_all_index(bot, message):
    await message.reply_text(
        'ᴛʜɪꜱ ᴡɪʟʟ ᴅᴇʟᴇᴛᴇ ᴀʟʟ ʏᴏᴜʀ ɪɴᴅᴇxᴇᴅ ꜰɪʟᴇꜱ !\nᴅᴏ ʏᴏᴜ ꜱᴛɪʟʟ ᴡᴀɴᴛ ᴛᴏ ᴄᴏɴᴛɪɴᴜᴇ ?',
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(
                        text="⚠️ ʏᴇꜱ ⚠️", callback_data="autofilter_delete"
                    )
                ],
                [
                    InlineKeyboardButton(
                        text="❌ ɴᴏ ❌", callback_data="close_data"
                    )
                ],
            ]
        ),
        quote=True,
    )


@Client.on_callback_query(filters.regex(r'^autofilter_delete'))
async def delete_all_index_confirm(bot, message):
    await Media.collection.drop()
    await Media2.collection.drop()
    await message.answer("Eᴠᴇʀʏᴛʜɪɴɢ's Gᴏɴᴇ")
    await message.message.edit('ꜱᴜᴄᴄᴇꜱꜱꜰᴜʟʟʏ ᴅᴇʟᴇᴛᴇᴅ ᴀʟʟ ɪɴᴅᴇxᴇᴅ ꜰɪʟᴇꜱ ✅')


@Client.on_message(filters.command('paramètres'))
async def paramètres(client, message):
    userid = message.from_user.id if message.from_user else None
    if not userid:
        return await message.reply(f"ʏᴏᴜ'ʀᴇ ᴀɴᴏɴʏᴍᴏᴜꜱ ᴀᴅᴍɪɴ.\nᴜꜱᴇ /connect {message.chat.id} ɪɴ ᴘᴍ.")
    chat_type = message.chat.type

    if chat_type == enums.ChatType.PRIVATE:
        grpid = await active_connection(str(userid))
        if grpid is not None:
            grp_id = grpid
            try:
                chat = await client.get_chat(grpid)
                title = chat.title
            except:
                await message.reply_text("ᴍᴀᴋᴇ ꜱᴜʀᴇ ɪ'ᴍ ᴘʀᴇꜱᴇɴᴛ ɪɴ ʏᴏᴜʀ ɢʀᴏᴜᴘ !!", quote=True)
                return
        else:
            await message.reply_text("ɪ'ᴍ ɴᴏᴛ ᴄᴏɴɴᴇᴄᴛᴇᴅ ᴛᴏ ᴀɴʏ ɢʀᴏᴜᴘ !", quote=True)
            return

    elif chat_type in [enums.ChatType.GROUP, enums.ChatType.SUPERGROUP]:
        grp_id = message.chat.id
        title = message.chat.title

    else:
        return

    st = await client.get_chat_member(grp_id, userid)
    if (
            st.status != enums.ChatMemberStatus.ADMINISTRATOR
            and st.status != enums.ChatMemberStatus.OWNER
            and str(userid) not in ADMINS
    ):
        return
    
    paramètres = await get_paramètres(grp_id)

    try:
        if paramètres['max_btn']:
            paramètres = await get_paramètres(grp_id)
    except KeyError:
        await save_group_paramètres(grp_id, 'max_btn', False)
        paramètres = await get_paramètres(grp_id)

    if paramètres is not None:
        buttons = [        
                [
                InlineKeyboardButton(
                    'ᴘᴀɢᴇ ᴅᴇ ʀᴇꜱᴜʟᴛᴀᴛꜱ',
                    callback_data=f'setgs#button#{paramètres["button"]}#{grp_id}',
                ),
                InlineKeyboardButton(
                    'ʙᴏᴜᴛᴏɴ' if paramètres["button"] else 'ᴛᴇxᴛᴇ',
                    callback_data=f'setgs#button#{paramètres["button"]}#{grp_id}',
                ),
            ],
            [
                InlineKeyboardButton(
                    'ᴍᴏᴅᴇ ᴅ\'ᴇɴᴠᴏɪ',
                    callback_data=f'setgs#botpm#{paramètres["botpm"]}#{grp_id}',
                ),
                InlineKeyboardButton(
                    'ᴘʀɪᴠᴇ' if paramètres["botpm"] else 'ᴀᴜᴛᴏ',
                    callback_data=f'setgs#botpm#{paramètres["botpm"]}#{grp_id}',
                ),
            ],
            [
                InlineKeyboardButton(
                    'ꜱᴇᴄᴜʀɪᴛᴇ ꜰɪᴄʜɪᴇʀ',
                    callback_data=f'setgs#file_secure#{paramètres["file_secure"]}#{grp_id}',
                ),
                InlineKeyboardButton(
                    'ᴀᴄᴛɪᴠᴇ' if paramètres["file_secure"] else 'ɪɴᴀᴄᴛɪꜰ',
                    callback_data=f'setgs#file_secure#{paramètres["file_secure"]}#{grp_id}',
                ),
            ],
            [
                InlineKeyboardButton(
                    'ᴀꜰꜰɪᴄʜᴇ ɪᴍᴅʙ',
                    callback_data=f'setgs#imdb#{paramètres["imdb"]}#{grp_id}',
                ),
                InlineKeyboardButton(
                    'ᴀᴄᴛɪᴠᴇ' if paramètres["imdb"] else 'ɪɴᴀᴄᴛɪꜰ',
                    callback_data=f'setgs#imdb#{paramètres["imdb"]}#{grp_id}',
                ),
            ],
            [
                InlineKeyboardButton(
                    'ᴄᴏʀʀᴇᴄᴛɪᴏɴ',
                    callback_data=f'setgs#spell_check#{paramètres["spell_check"]}#{grp_id}',
                ),
                InlineKeyboardButton(
                    'ᴀᴄᴛɪᴠᴇ' if paramètres["spell_check"] else 'ɪɴᴀᴄᴛɪꜰ',
                    callback_data=f'setgs#spell_check#{paramètres["spell_check"]}#{grp_id}',
                ),
            ],
            [
                InlineKeyboardButton(
                    'ᴍꜱɢ ᴀᴄᴄᴜᴇɪʟ',
                    callback_data=f'setgs#welcome#{paramètres["welcome"]}#{grp_id}',
                ),
                InlineKeyboardButton(
                    'ᴀᴄᴛɪᴠᴇ' if paramètres["welcome"] else 'ɪɴᴀᴄᴛɪꜰ',
                    callback_data=f'setgs#welcome#{paramètres["welcome"]}#{grp_id}',
                ),
            ],
            [
                InlineKeyboardButton(
                    'ꜱᴜᴘᴘʀᴇꜱꜱɪᴏɴ ᴀᴜᴛᴏ',
                    callback_data=f'setgs#auto_delete#{paramètres["auto_delete"]}#{grp_id}',
                ),
                InlineKeyboardButton(
                    'ᴀᴄᴛɪᴠᴇ' if paramètres["auto_delete"] else 'ɪɴᴀᴄᴛɪꜰ',
                    callback_data=f'setgs#auto_delete#{paramètres["auto_delete"]}#{grp_id}',
                ),
            ],
            [
                InlineKeyboardButton(
                    'ꜰɪʟᴛʀᴇ ᴀᴜᴛᴏ',
                    callback_data=f'setgs#auto_ffilter#{paramètres["auto_ffilter"]}#{grp_id}',
                ),
                InlineKeyboardButton(
                    'ᴀᴄᴛɪᴠᴇ' if paramètres["auto_ffilter"] else 'ɪɴᴀᴄᴛɪꜰ',
                    callback_data=f'setgs#auto_ffilter#{paramètres["auto_ffilter"]}#{grp_id}',
                ),
            ],
            [
                InlineKeyboardButton(
                    'ᴍᴀx ʙᴏᴜᴛᴏɴꜱ',
                    callback_data=f'setgs#max_btn#{paramètres["max_btn"]}#{grp_id}',
                ),
                InlineKeyboardButton(
                    '10' if paramètres["max_btn"] else f'{MAX_B_TN}',
                    callback_data=f'setgs#max_btn#{paramètres["max_btn"]}#{grp_id}',
                ),
            ],
            [
                InlineKeyboardButton('⇋ ᴄʟᴏꜱᴇ ᴘᴀʀᴀᴍᴇᴛʀᴇꜱ ᴍᴇɴᴜ ⇋', 
                                     callback_data='close_data'
                                     )
            ]
        ]
        

        btn = [[
                InlineKeyboardButton("👤 ᴏᴘᴇɴ ɪɴ ᴘʀɪᴠᴀᴛᴇ ᴄʜᴀᴛ 👤", callback_data=f"opnsetpm#{grp_id}")
              ],[
                InlineKeyboardButton("👥 ᴏᴘᴇɴ ʜᴇʀᴇ 👥", callback_data=f"opnsetgrp#{grp_id}")
              ]]

        reply_markup = InlineKeyboardMarkup(buttons)
        if chat_type in [enums.ChatType.GROUP, enums.ChatType.SUPERGROUP]:
            await message.reply_text(
                text="<b>ᴡʜᴇʀᴇ ᴅᴏ ʏᴏᴜ ᴡᴀɴᴛ ᴛᴏ ᴏᴘᴇɴ ᴘᴀʀᴀᴍᴇᴛʀᴇꜱ ᴍᴇɴᴜ ? ⚙️</b>",
                reply_markup=InlineKeyboardMarkup(btn),
                disable_web_page_preview=True,
                parse_mode=enums.ParseMode.HTML,
                reply_to_message_id=message.id
            )
        else:
            await message.reply_text(
                text=f"<b>ᴄʜᴀɴɢᴇ ʏᴏᴜʀ ᴘᴀʀᴀᴍᴇᴛʀᴇꜱ ꜰᴏʀ {title} ᴀꜱ ʏᴏᴜ ᴡɪꜱʜ ⚙</b>",
                reply_markup=reply_markup,
                disable_web_page_preview=True,
                parse_mode=enums.ParseMode.HTML,
                reply_to_message_id=message.id
            )



@Client.on_message(filters.command('set_template'))
async def save_template(client, message):
    sts = await message.reply("ᴄʜᴇᴄᴋɪɴɢ ᴛᴇᴍᴘʟᴀᴛᴇ...")
    userid = message.from_user.id if message.from_user else None
    if not userid:
        return await message.reply(f"ʏᴏᴜ'ʀᴇ ᴀɴᴏɴʏᴍᴏᴜꜱ ᴀᴅᴍɪɴ.\nᴜꜱᴇ /connect {message.chat.id} ɪɴ ᴘᴍ.")
    chat_type = message.chat.type

    if chat_type == enums.ChatType.PRIVATE:
        grpid = await active_connection(str(userid))
        if grpid is not None:
            grp_id = grpid
            try:
                chat = await client.get_chat(grpid)
                title = chat.title
            except:
                await message.reply_text("ᴍᴀᴋᴇ ꜱᴜʀᴇ ɪ'ᴍ ᴘʀᴇꜱᴇɴᴛ ɪɴ ʏᴏᴜʀ ɢʀᴏᴜᴘ !!", quote=True)
                return
        else:
            await message.reply_text("ɪ'ᴍ ɴᴏᴛ ᴄᴏɴɴᴇᴄᴛᴇᴅ ᴛᴏ ᴀɴʏ ɢʀᴏᴜᴘ !", quote=True)
            return

    elif chat_type in [enums.ChatType.GROUP, enums.ChatType.SUPERGROUP]:
        grp_id = message.chat.id
        title = message.chat.title

    else:
        return

    st = await client.get_chat_member(grp_id, userid)
    if (
            st.status != enums.ChatMemberStatus.ADMINISTRATOR
            and st.status != enums.ChatMemberStatus.OWNER
            and str(userid) not in ADMINS
    ):
        return

    if len(message.command) < 2:
        return await sts.edit("ɴᴏ ɪɴᴘᴜᴛ !")
    template = message.text.split(" ", 1)[1]
    await save_group_paramètres(grp_id, 'template', template)
    await sts.edit(f"✅ ꜱᴜᴄᴄᴇꜱꜱꜰᴜʟʟʏ ᴄʜᴀɴɢᴇᴅ ᴛᴇᴍᴘʟᴀᴛᴇ ꜰᴏʀ <code>{title}</code> ᴛᴏ\n\n{template}")


@Client.on_message((filters.command(["request", "Request"]) | filters.regex("#request") | filters.regex("#Request")) & filters.group)
async def requests(bot, message):
    if REQST_CHANNEL is None or SUPPORT_CHAT_ID is None: return # Must add REQST_CHANNEL and SUPPORT_CHAT_ID to use this feature
    if message.reply_to_message and SUPPORT_CHAT_ID == message.chat.id:
        chat_id = message.chat.id
        reporter = str(message.from_user.id)
        mention = message.from_user.mention
        success = True
        content = message.reply_to_message.text
        try:
            if REQST_CHANNEL is not None:
                btn = [[
                        InlineKeyboardButton('ᴠᴏɪʀ ʟᴀ ᴅᴇᴍᴀɴᴅᴇ', url=f"{message.reply_to_message.link}"),
                        InlineKeyboardButton('ᴀꜰꜰɪᴄʜᴇʀ ʟᴇꜱ ᴏᴘᴛɪᴏɴꜱ', callback_data=f'show_option#{reporter}')
                      ]]
                reported_post = await bot.send_message(chat_id=REQST_CHANNEL, text=f"<b>📝 ʀᴇǫᴜᴇꜱᴛ : <u>{content}</u>\n\n📚 ᴇɴᴠᴏʏᴇ ᴘᴀʀ : {mention}\n📖 ɪᴅ ᴇxᴘᴇᴅɪᴛᴇᴜʀ : {reporter}\n\n</b>", reply_markup=InlineKeyboardMarkup(btn))
                success = True
            elif len(content) >= 3:
                for admin in ADMINS:
                    btn = [[
                        InlineKeyboardButton('ᴠᴏɪʀ ʟᴀ ᴅᴇᴍᴀɴᴅᴇ', url=f"{message.reply_to_message.link}"),
                        InlineKeyboardButton('ᴀꜰꜰɪᴄʜᴇʀ ʟᴇꜱ ᴏᴘᴛɪᴏɴꜱ', callback_data=f'show_option#{reporter}')
                      ]]
                    reported_post = await bot.send_message(chat_id=admin, text=f"<b>📝 ʀᴇǫᴜᴇꜱᴛ : <u>{content}</u>\n\n📚 ᴇɴᴠᴏʏᴇ ᴘᴀʀ : {mention}\n📖 ɪᴅ ᴇxᴘᴇᴅɪᴛᴇᴜʀ : {reporter}\n\n</b>", reply_markup=InlineKeyboardMarkup(btn))
                    success = True
            else:
                if len(content) < 3:
                    await message.reply_text("<b>ᴠᴏᴜꜱ ᴅᴇᴠᴇᴢ ᴛᴀᴘᴇʀ ᴠᴏᴛʀᴇ ᴅᴇᴍᴀɴᴅᴇ [ᴍɪɴɪᴍᴜᴍ 3 ᴄᴀʀᴀᴄᴛᴇʀᴇꜱ]. ʟᴇꜱ ᴅᴇᴍᴀɴᴅᴇꜱ ɴᴇ ᴘᴇᴜᴠᴇɴᴛ ᴘᴀꜱ ᴇᴛʀᴇ ᴠɪᴅᴇꜱ.</b>")
            if len(content) < 3:
                success = False
        except Exception as e:
            await message.reply_text(f"<b>ᴇʀʀᴇᴜʀ : {e}</b>")
            pass
        
    elif SUPPORT_CHAT_ID == message.chat.id:
        chat_id = message.chat.id
        reporter = str(message.from_user.id)
        mention = message.from_user.mention
        success = True
        content = message.text
        keywords = ["#request", "/request", "#Request", "/Request"]
        for keyword in keywords:
            if keyword in content:
                content = content.replace(keyword, "")
        try:
            if REQST_CHANNEL is not None and len(content) >= 3:
                btn = [[
                        InlineKeyboardButton('ᴠᴏɪʀ ʟᴀ ᴅᴇᴍᴀɴᴅᴇ', url=f"{message.link}"),
                        InlineKeyboardButton('ᴀꜰꜰɪᴄʜᴇʀ ʟᴇꜱ ᴏᴘᴛɪᴏɴꜱ', callback_data=f'show_option#{reporter}')
                      ]]
                reported_post = await bot.send_message(chat_id=REQST_CHANNEL, text=f"<b>📝 ʀᴇǫᴜᴇꜱᴛ : <u>{content}</u>\n\n📚 ᴇɴᴠᴏʏᴇ ᴘᴀʀ : {mention}\n📖 ɪᴅ ᴇxᴘᴇᴅɪᴛᴇᴜʀ : {reporter}\n\n</b>", reply_markup=InlineKeyboardMarkup(btn))
                success = True
            elif len(content) >= 3:
                for admin in ADMINS:
                    btn = [[
                        InlineKeyboardButton('ᴠᴏɪʀ ʟᴀ ᴅᴇᴍᴀɴᴅᴇ', url=f"{message.link}"),
                        InlineKeyboardButton('ᴀꜰꜰɪᴄʜᴇʀ ʟᴇꜱ ᴏᴘᴛɪᴏɴꜱ', callback_data=f'show_option#{reporter}')
                      ]]
                    reported_post = await bot.send_message(chat_id=admin, text=f"<b>📝 ʀᴇǫᴜᴇꜱᴛ : <u>{content}</u>\n\n📚 ᴇɴᴠᴏʏᴇ ᴘᴀʀ : {mention}\n📖 ɪᴅ ᴇxᴘᴇᴅɪᴛᴇᴜʀ : {reporter}\n\n</b>", reply_markup=InlineKeyboardMarkup(btn))
                    success = True
            else:
                if len(content) < 3:
                    await message.reply_text("<b>ᴠᴏᴜꜱ ᴅᴇᴠᴇᴢ ᴛᴀᴘᴇʀ ᴠᴏᴛʀᴇ ᴅᴇᴍᴀɴᴅᴇ [ᴍɪɴɪᴍᴜᴍ 3 ᴄᴀʀᴀᴄᴛᴇʀᴇꜱ]. ʟᴇꜱ ᴅᴇᴍᴀɴᴅᴇꜱ ɴᴇ ᴘᴇᴜᴠᴇɴᴛ ᴘᴀꜱ ᴇᴛʀᴇ ᴠɪᴅᴇꜱ.</b>")
            if len(content) < 3:
                success = False
        except Exception as e:
            await message.reply_text(f"<b>ᴇʀʀᴇᴜʀ : {e}</b>")
            pass
     
    elif SUPPORT_CHAT_ID == message.chat.id:
        chat_id = message.chat.id
        reporter = str(message.from_user.id)
        mention = message.from_user.mention
        success = True
        content = message.text
        keywords = ["#request", "/request", "#Request", "/Request"]
        for keyword in keywords:
            if keyword in content:
                content = content.replace(keyword, "")
        try:
            if REQST_CHANNEL is not None and len(content) >= 3:
                btn = [[
                        InlineKeyboardButton('ᴠᴏɪʀ ʟᴀ ᴅᴇᴍᴀɴᴅᴇ', url=f"{message.link}"),
                        InlineKeyboardButton('ᴀꜰꜰɪᴄʜᴇʀ ʟᴇꜱ ᴏᴘᴛɪᴏɴꜱ', callback_data=f'show_option#{reporter}')
                      ]]
                reported_post = await bot.send_message(chat_id=REQST_CHANNEL, text=f"<b>📝 ʀᴇǫᴜᴇꜱᴛ : <u>{content}</u>\n\n📚 ᴇɴᴠᴏʏᴇ ᴘᴀʀ : {mention}\n📖 ɪᴅ ᴇxᴘᴇᴅɪᴛᴇᴜʀ : {reporter}\n\n</b>", reply_markup=InlineKeyboardMarkup(btn))
                success = True
            elif len(content) >= 3:
                for admin in ADMINS:
                    btn = [[
                        InlineKeyboardButton('ᴠᴏɪʀ ʟᴀ ᴅᴇᴍᴀɴᴅᴇ', url=f"{message.link}"),
                        InlineKeyboardButton('ᴀꜰꜰɪᴄʜᴇʀ ʟᴇꜱ ᴏᴘᴛɪᴏɴꜱ', callback_data=f'show_option#{reporter}')
                      ]]
                    reported_post = await bot.send_message(chat_id=admin, text=f"<b>📝 ʀᴇǫᴜᴇꜱᴛ : <u>{content}</u>\n\n📚 ᴇɴᴠᴏʏᴇ ᴘᴀʀ : {mention}\n📖 ɪᴅ ᴇxᴘᴇᴅɪᴛᴇᴜʀ : {reporter}\n\n</b>", reply_markup=InlineKeyboardMarkup(btn))
                    success = True
            else:
                if len(content) < 3:
                    await message.reply_text("<b>ᴠᴏᴜꜱ ᴅᴇᴠᴇᴢ ᴛᴀᴘᴇʀ ᴠᴏᴛʀᴇ ᴅᴇᴍᴀɴᴅᴇ [ᴍɪɴɪᴍᴜᴍ 3 ᴄᴀʀᴀᴄᴛᴇʀᴇꜱ]. ʟᴇꜱ ᴅᴇᴍᴀɴᴅᴇꜱ ɴᴇ ᴘᴇᴜᴠᴇɴᴛ ᴘᴀꜱ ᴇᴛʀᴇ ᴠɪᴅᴇꜱ.</b>")
            if len(content) < 3:
                success = False
        except Exception as e:
            await message.reply_text(f"<b>ᴇʀʀᴇᴜʀ : {e}</b>")
            pass

    else:
        success = False
    
    if success:
        '''if isinstance(REQST_CHANNEL, (int, str)):
            channels = [REQST_CHANNEL]
        elif isinstance(REQST_CHANNEL, list):
            channels = REQST_CHANNEL
        for channel in channels:
            chat = await bot.get_chat(channel)
        #chat = int(chat)'''
        link = await bot.create_chat_invite_link(int(REQST_CHANNEL))
        btn = [[
                InlineKeyboardButton('ʀᴇᴊᴏɪɴᴅʀᴇ ʟᴇ ᴄᴀɴᴀʟ', url=link.invite_link),
                InlineKeyboardButton('ᴠᴏɪʀ ʟᴀ ᴅᴇᴍᴀɴᴅᴇ', url=f"{reported_post.link}")
              ]]
        await message.reply_text("<b>ᴠᴏᴛʀᴇ ᴅᴇᴍᴀɴᴅᴇ ᴀ ᴇᴛᴇ ᴇɴʀᴇɢɪꜱᴛʀᴇᴇ ! ᴠᴇᴜɪʟʟᴇᴢ ᴘᴀᴛɪᴇɴᴛᴇʀ.\n\nʀᴇᴊᴏɪɢɴᴇᴢ ʟᴇ ᴄᴀɴᴀʟ & ꜱᴜɪᴠᴇᴢ ᴠᴏᴛʀᴇ ᴅᴇᴍᴀɴᴅᴇ.</b>", reply_markup=InlineKeyboardMarkup(btn))
    
@Client.on_message(filters.command("send") & filters.user(ADMINS))
async def send_msg(bot, message):
    if message.reply_to_message:
        target_id = message.text.split(" ", 1)[1]
        out = "Users Saved In DB Are:\n\n"
        success = False
        try:
            user = await bot.get_users(target_id)
            users = await db.get_all_users()
            async for usr in users:
                out += f"{usr['id']}"
                out += '\n'
            if str(user.id) in str(out):
                await message.reply_to_message.copy(int(user.id))
                success = True
            else:
                success = False
            if success:
                await message.reply_text(f"<b>ʏᴏᴜʀ ᴍᴇꜱꜱᴀɢᴇ ʜᴀꜱ ʙᴇᴇɴ ꜱᴜᴄᴄᴇꜱꜱꜰᴜʟʟʏ ꜱᴇɴᴛ ᴛᴏ {user.mention}.</b>")
            else:
                await message.reply_text("<b>ᴄᴇᴛ ᴜᴛɪʟɪꜱᴀᴛᴇᴜʀ ɴ'ᴀ ᴘᴀꜱ ᴇɴᴄᴏʀᴇ ᴅᴇᴍᴀʀʀᴇ ᴄᴇ ʙᴏᴛ !</b>")
        except Exception as e:
            await message.reply_text(f"<b>ᴇʀʀᴇᴜʀ : {e}</b>")
    else:
        await message.reply_text("<b>ᴜꜱᴇ ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ ᴀꜱ ᴀ ʀᴇᴘʟʏ ᴛᴏ ᴀɴʏ ᴍᴇꜱꜱᴀɢᴇ ᴜꜱɪɴɢ ᴛʜᴇ ᴛᴀʀɢᴇᴛ ᴄʜᴀᴛ ɪᴅ. ꜰᴏʀ ᴇɢ:  /send ᴜꜱᴇʀɪᴅ</b>")

@Client.on_message(filters.command("deletefiles") & filters.user(ADMINS))
async def deletemultiplefiles(bot, message):
    chat_type = message.chat.type
    if chat_type != enums.ChatType.PRIVATE:
        return await message.reply_text(f"<b>Salut {message.from_user.mention}, cette commande ne fonctionne pas dans les groupes. Elle fonctionne uniquement en MP !</b>")
    else:
        pass
    try:
        keyword = message.text.split(" ", 1)[1]
    except:
        return await message.reply_text(f"<b>Salut {message.from_user.mention}, donnez-moi un mot-clé avec la commande pour supprimer les fichiers.</b>")
    k = await bot.send_message(chat_id=message.chat.id, text=f"<b>Recherche des fichiers pour votre requête {keyword} dans la base... Veuillez patienter...</b>")
    files, total = await get_bad_files(keyword)
    await k.delete()
    #await k.edit_text(f"<b>Found {total} files for your query {keyword} !\n\nFile deletion process will start in 5 seconds !</b>")
    #await asyncio.sleep(5)
    btn = [[
       InlineKeyboardButton("⚠️ ᴏᴜɪ, ᴄᴏɴᴛɪɴᴜᴇʀ ! ⚠️", callback_data=f"killfilesdq#{keyword}")
       ],[
       InlineKeyboardButton("❌ ɴᴏɴ, ᴀɴɴᴜʟᴇʀ ! ❌", callback_data="close_data")
    ]]
    await message.reply_text(
        text=f"<b>Found {total} files for your query {keyword} !\n\nDo you want to delete?</b>",
        reply_markup=InlineKeyboardMarkup(btn),
        parse_mode=enums.ParseMode.HTML
    )

@Client.on_message(filters.command("set_tutorial"))
async def settutorial(bot, message):
    userid = message.from_user.id if message.from_user else None
    if not userid:
        return await message.reply(f"ʏᴏᴜ'ʀᴇ ᴀɴᴏɴʏᴍᴏᴜꜱ ᴀᴅᴍɪɴ, ᴛᴜʀɴ ᴏꜰꜰ ᴀɴᴏɴʏᴍᴏᴜꜱ ᴀᴅᴍɪɴ ᴀɴᴅ ᴛʀʏ ᴀɢᴀɪɴ ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ.")
    chat_type = message.chat.type
    if chat_type == enums.ChatType.PRIVATE:
        return await message.reply_text("ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ ᴡᴏʀᴋꜱ ᴏɴʟʏ ɪɴ ɢʀᴏᴜᴘꜱ !")
    elif chat_type in [enums.ChatType.GROUP, enums.ChatType.SUPERGROUP]:
        grpid = message.chat.id
        title = message.chat.title
    else:
        return
    userid = message.from_user.id
    user = await bot.get_chat_member(grpid, userid)
    if user.status != enums.ChatMemberStatus.ADMINISTRATOR and user.status != enums.ChatMemberStatus.OWNER and str(userid) not in ADMINS:
        return
    else:
        pass
    if len(message.command) == 1:
        return await message.reply("<b>ɢɪᴠᴇ ᴍᴇ ᴀ ᴛᴜᴛᴏʀɪᴀʟ ʟɪɴᴋ ᴀʟᴏɴɢ ᴡɪᴛʜ ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ.\n\nᴜꜱᴀɢᴇ : /set_tutorial <code>https://t.me/HowToOpenHP</code></b>")
    elif len(message.command) == 2:
        reply = await message.reply_text("<b>ᴠᴇᴜɪʟʟᴇᴢ ᴘᴀᴛɪᴇɴᴛᴇʀ...</b>")
        tutorial = message.command[1]
        await save_group_paramètres(grpid, 'tutorial', tutorial)
        await save_group_paramètres(grpid, 'is_tutorial', True)
        await reply.edit_text(f"<b>✅ ꜱᴜᴄᴄᴇꜱꜱꜰᴜʟʟʏ ᴀᴅᴅᴇᴅ ᴛᴜᴛᴏʀɪᴀʟ\n\nʏᴏᴜʀ ɢʀᴏᴜᴘ : {title}\n\nʏᴏᴜʀ ᴛᴜᴛᴏʀɪᴀʟ : <code>{tutorial}</code></b>")
    else:
        return await message.reply("<b>ʏᴏᴜ ᴇɴᴛᴇʀᴇᴅ ɪɴᴄᴏʀʀᴇᴄᴛ ꜰᴏʀᴍᴀᴛ !\nᴄᴏʀʀᴇᴄᴛ ꜰᴏʀᴍᴀᴛ : /set_tutorial <code>https://t.me/HowToOpenHP</code></b>")

@Client.on_message(filters.command("remove_tutorial"))
async def removetutorial(bot, message):
    userid = message.from_user.id if message.from_user else None
    if not userid:
        return await message.reply(f"ʏᴏᴜ'ʀᴇ ᴀɴᴏɴʏᴍᴏᴜꜱ ᴀᴅᴍɪɴ, ᴛᴜʀɴ ᴏꜰꜰ ᴀɴᴏɴʏᴍᴏᴜꜱ ᴀᴅᴍɪɴ ᴀɴᴅ ᴛʀʏ ᴀɢᴀɪɴ ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ.")
    chat_type = message.chat.type
    if chat_type == enums.ChatType.PRIVATE:
        return await message.reply_text("ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ ᴏɴʟʏ ᴡᴏʀᴋꜱ ɪɴ ɢʀᴏᴜᴘꜱ !")
    elif chat_type in [enums.ChatType.GROUP, enums.ChatType.SUPERGROUP]:
        grpid = message.chat.id
        title = message.chat.title
    else:
        return
    userid = message.from_user.id
    user = await bot.get_chat_member(grpid, userid)
    if user.status != enums.ChatMemberStatus.ADMINISTRATOR and user.status != enums.ChatMemberStatus.OWNER and str(userid) not in ADMINS:
        return
    else:
        pass
    reply = await message.reply_text("<b>ᴠᴇᴜɪʟʟᴇᴢ ᴘᴀᴛɪᴇɴᴛᴇʀ...</b>")
    await save_group_paramètres(grpid, 'is_tutorial', False)
    await reply.edit_text(f"<b>ꜱᴜᴄᴄᴇꜱꜱꜰᴜʟʟʏ ʀᴇᴍᴏᴠᴇᴅ ᴛᴜᴛᴏʀɪᴀʟ ʟɪɴᴋ ✅</b>")
    

@Client.on_callback_query(filters.regex("topsearch"))
async def topsearch_callback(client, callback_query):
    
    def is_alphanumeric(string):
        return bool(re.match('^[a-zA-Z0-9 ]*$', string))
    
    limit = 20  
    top_messages = await mdb.get_top_messages(limit)
    seen_messages = set()
    truncated_messages = []
    for msg in top_messages:
        msg_lower = msg.lower()
        if msg_lower not in seen_messages and is_alphanumeric(msg):
            seen_messages.add(msg_lower)
            
            if len(msg) > 35:
                truncated_messages.append(msg[:32] + "...")
            else:
                truncated_messages.append(msg)
    keyboard = [truncated_messages[i:i+2] for i in range(0, len(truncated_messages), 2)]
    reply_markup = ReplyKeyboardMarkup(
        keyboard, 
        one_time_keyboard=True, 
        resize_keyboard=True, 
        placeholder="Most searches of the day"
    )
    await callback_query.message.reply_text("<b>Tᴏᴘ Sᴇᴀʀᴄʜᴇs Oғ Tʜᴇ Dᴀʏ 👇</b>", reply_markup=reply_markup)
    await callback_query.answer()

@Client.on_message(filters.command('top_search'))
async def top(_, message):
    def is_alphanumeric(string):
        return bool(re.match('^[a-zA-Z0-9 ]*$', string))
    try:
        limit = int(message.command[1])
    except (IndexError, ValueError):
        limit = 20
    top_messages = await mdb.get_top_messages(limit)
    seen_messages = set()
    truncated_messages = []
    for msg in top_messages:
        if msg.lower() not in seen_messages and is_alphanumeric(msg):
            seen_messages.add(msg.lower())
            
            if len(msg) > 35:
                truncated_messages.append(msg[:35 - 3])
            else:
                truncated_messages.append(msg)
    keyboard = []
    for i in range(0, len(truncated_messages), 2):
        row = truncated_messages[i:i+2]
        keyboard.append(row)
    reply_markup = ReplyKeyboardMarkup(keyboard, one_time_keyboard=True, resize_keyboard=True, placeholder="Most searches of the day")
    await message.reply_text(f"<b>Tᴏᴘ Sᴇᴀʀᴄʜᴇs Oғ Tʜᴇ Dᴀʏ 👇</b>", reply_markup=reply_markup)

    
@Client.on_message(filters.command('trendlist'))
async def trendlist(client, message):
    def is_alphanumeric(string):
        return bool(re.match('^[a-zA-Z0-9 ]*$', string))
    limit = 31
    if len(message.command) > 1:
        try:
            limit = int(message.command[1])
        except ValueError:
            await message.reply_text("Invalid number format.\nPlease provide a valid number after the /trendlist command.")
            return 
    try:
        top_messages = await mdb.get_top_messages(limit)
    except Exception as e:
        await message.reply_text(f"Error retrieving messages: {str(e)}")
        return  

    if not top_messages:
        await message.reply_text("No top messages found.")
        return 
    seen_messages = set()
    truncated_messages = []

    for msg in top_messages:
        if msg.lower() not in seen_messages and is_alphanumeric(msg):
            seen_messages.add(msg.lower())
            truncated_messages.append(msg[:32] + '...' if len(msg) > 35 else msg)

    if not truncated_messages:
        await message.reply_text("No valid top messages found.")
        return  
    formatted_list = "\n".join([f"{i+1}. <b>{msg}</b>" for i, msg in enumerate(truncated_messages)])
    additional_message = "⚡️ 𝑨𝒍𝒍 𝒕𝒉𝒆 𝒓𝒆𝒔𝒖𝒍𝒕𝒔 𝒂𝒃𝒐𝒗𝒆 𝒄𝒐𝒎𝒆 𝒇𝒓𝒐𝒎 𝒘𝒉𝒂𝒕 𝒖𝒔𝒆𝒓𝒔 𝒉𝒂𝒗𝒆 𝒔𝒆𝒂𝒓𝒄𝒉𝒆𝒅 𝒇𝒐𝒓. 𝑻𝒉𝒆𝒚'𝒓𝒆 𝒔𝒉𝒐𝒘𝒏 𝒕𝒐 𝒚𝒐𝒖 𝒆𝒙𝒂𝒄𝒕𝒍𝒚 𝒂𝒔 𝒕𝒉𝒆𝒚 𝒘𝒆𝒓𝒆 𝒔𝒆𝒂𝒓𝒄𝒉𝒆𝒅, 𝒘𝒊𝒕𝒉𝒐𝒖𝒕 𝒂𝒏𝒚 𝒄𝒉𝒂𝒏𝒈𝒆𝒔 𝒃𝒚 𝒕𝒉𝒆 𝒐𝒘𝒏𝒆𝒓."
    formatted_list += f"\n\n{additional_message}"
    reply_text = f"<b>Top {len(truncated_messages)} Tʀᴀɴᴅɪɴɢ ᴏғ ᴛʜᴇ ᴅᴀʏ 👇:</b>\n\n{formatted_list}"
    await message.reply_text(reply_text)

@Client.on_message(filters.private & filters.command("pm_search") & filters.user(ADMINS))
async def set_pm_search(client, message):
    bot_id = client.me.id
    try:
        option = message.text.split(" ", 1)[1].strip().lower()
        enable_status = option in ['on', 'true']
    except (IndexError, ValueError):
        await message.reply_text("<b>💔 Option invalide. Veuillez envoyer 'on' ou 'off' après la commande.</b>")
        return
    try:
        await db.update_pm_search_status(bot_id, enable_status)
        response_text = (
            "<b>ʀᴇᴄʜᴇʀᴄʜᴇ ᴇɴ ᴍᴘ ᴀᴄᴛɪᴠᴇᴇ ✅</b>" if enable_status 
            else "<b>ʀᴇᴄʜᴇʀᴄʜᴇ ᴇɴ ᴍᴘ ᴅᴇꜱᴀᴄᴛɪᴠᴇᴇ ❌</b>"
        )
        await message.reply_text(response_text)
    except Exception as e:
        await log_error(client, f"Error in set_pm_search: {e}")
        await message.reply_text(f"<b>❗ Une erreur est survenue : {e}</b>")

@Client.on_message(filters.private & filters.command("movie_update") & filters.user(ADMINS))
async def set_movie_update_notification(client, message):
    bot_id = client.me.id
    try:
        option = message.text.split(" ", 1)[1].strip().lower()
        enable_status = option in ['on', 'true']
    except (IndexError, ValueError):
        await message.reply_text("<b>💔 Option invalide. Veuillez envoyer 'on' ou 'off' après la commande.</b>")
        return
    try:
        await db.update_movie_update_status(bot_id, enable_status)
        response_text = (
            "<b>ɴᴏᴛɪꜰɪᴄᴀᴛɪᴏɴ ᴍɪꜱᴇ ᴀ ᴊᴏᴜʀ ᴀᴄᴛɪᴠᴇᴇ ✅</b>" if enable_status 
            else "<b>ɴᴏᴛɪꜰɪᴄᴀᴛɪᴏɴ ᴍɪꜱᴇ ᴀ ᴊᴏᴜʀ ᴅᴇꜱᴀᴄᴛɪᴠᴇᴇ ❌</b>"
        )
        await message.reply_text(response_text)
    except Exception as e:
        await log_error(client, f"Error in set_movie_update_notification: {e}")
        await message.reply_text(f"<b>❗ Une erreur est survenue : {e}</b>")

@Client.on_message(filters.command("restart") & filters.user(ADMINS))
async def stop_button(bot, message):
    msg = await bot.send_message(text="<b><i>ʟᴇ ʙᴏᴛ ʀᴇᴅᴇᴍᴀʀʀᴇ</i></b>", chat_id=message.chat.id)       
    await asyncio.sleep(3)
    await msg.edit("<b><i><u>ʟᴇ ʙᴏᴛ ᴀ ʀᴇᴅᴇᴍᴀʀʀᴇ</u> ✅</i></b>")
    os.execl(sys.executable, sys.executable, *sys.argv)

async def log_error(client, error_message):
    """Logs errors to the specified LOG_CHANNEL."""
    try:
        await client.send_message(
            chat_id=LOG_CHANNEL, 
            text=f"<b>⚠️ ᴊᴏᴜʀɴᴀʟ ᴅᴇꜱ ᴇʀʀᴇᴜʀꜱ :</b>\n<code>{error_message}</code>"
        )
    except Exception as e:
        print(f"Failed to log error: {e}")

@Client.on_message(filters.command("del_msg") & filters.user(ADMINS))
async def del_msg(client, message):
    user_id = message.from_user.id
    confirm_markup = InlineKeyboardMarkup([
        [InlineKeyboardButton("ᴏᴜɪ", callback_data="confirm_del_yes"),
         InlineKeyboardButton("ɴᴏɴ", callback_data="confirm_del_no")]
    ])
    sent_message = await message.reply_text(
        "⚠️ Aʀᴇ ʏᴏᴜ sᴜʀᴇ ʏᴏᴜ ᴡᴀɴᴛ ᴛᴏ ᴄʟᴇᴀʀ ᴛʜᴇ ᴜᴘᴅᴀᴛᴇs ᴄʜᴀɴɴᴇʟ ʟɪsᴛ ?\n\n ᴅᴏ ʏᴏᴜ ꜱᴛɪʟʟ ᴡᴀɴᴛ ᴛᴏ ᴄᴏɴᴛɪɴᴜᴇ ?",
        reply_markup=confirm_markup
    )
    await asyncio.sleep(60)
    try:
        await sent_message.delete()
    except Exception as e:
        print(f"Error deleting the message: {e}")

@Client.on_callback_query(filters.regex('^confirm_del_'))
async def confirmation_handler(client, callback_query):
    user_id = callback_query.from_user.id
    action = callback_query.data.split("_")[-1]  
    if action == "yes":
        await delete_all_msg(user_id)
        await callback_query.message.edit_text(
            '🧹 ᴜᴘᴅᴀᴛᴇꜱ ᴄʜᴀɴɴᴇʟ ʟɪsᴛ ʜᴀs ʙᴇᴇɴ ᴄʟᴇᴀʀᴇᴅ sᴜᴄᴄᴇssғᴜʟʟʏ ✅'
        )
    elif action == "no":
        await callback_query.message.delete()
    await callback_query.answer()
