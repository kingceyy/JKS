import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Icon } from "@/components/Icons";
import { useUserData, formatRemaining } from "@/hooks/useUserData";
import { PLAN_COLORS, PLAN_LABELS, PREMIUM_PLANS, USDT_WALLET, SUPPORT_TG, type PremiumPlan } from "@/utils/constants";
import { openTelegramLink, hapticFeedback } from "@/utils/telegram";
import { Faq } from "./AccessPage";

const PLAN_ICONS = {
  bronze: Icon.Medal, argent: Icon.Medal, or: Icon.Medal,
  platine: Icon.Diamond, diamant: Icon.Diamond, adamantide: Icon.Flame,
} as const;

function BottomSheet({ open, onClose, children }: { open: boolean; onClose: () => void; children: React.ReactNode }) {
  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60]" style={{ background: "rgba(0,0,0,0.6)" }} onClick={onClose} />
          <motion.div
            initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="fixed left-0 right-0 bottom-0 z-[70] p-6 rounded-t-3xl"
            style={{ background: "var(--bg-secondary)", paddingBottom: "calc(24px + env(safe-area-inset-bottom))" }}
          >
            <div className="w-10 h-1 rounded-full mx-auto mb-4" style={{ background: "rgba(255,255,255,0.15)" }} />
            {children}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

export function PremiumPage() {
  const { data } = useUserData();
  const [tonPlan, setTonPlan] = useState<PremiumPlan | null>(null);
  const [usdtPlan, setUsdtPlan] = useState<PremiumPlan | null>(null);

  if (!data) return null;
  const isPremium = data.plan !== "free" && data.premiumExpiry && new Date(data.premiumExpiry).getTime() > Date.now();

  return (
    <div className="space-y-5">
      {isPremium && (
        <div className="rounded-2xl p-4" style={{
          background: `linear-gradient(135deg, ${PLAN_COLORS[data.plan]}33, ${PLAN_COLORS[data.plan]}0d)`,
          border: `1px solid ${PLAN_COLORS[data.plan]}40`,
        }}>
          <div className="flex justify-between">
            <div>
              <div className="text-xs opacity-50">Plan actuel</div>
              <div className="font-bold text-lg" style={{ color: PLAN_COLORS[data.plan] }}>{PLAN_LABELS[data.plan]}</div>
            </div>
            <div className="text-right">
              <div className="text-xs opacity-50">Temps restant</div>
              <div className="font-bold text-lg" style={{ color: "var(--success)" }}>{formatRemaining(data.premiumExpiry)}</div>
            </div>
          </div>
          <div className="text-xs opacity-40 mt-2">Expire le {new Date(data.premiumExpiry!).toLocaleDateString("fr-FR")}</div>
        </div>
      )}

      <div className="text-center">
        <h2 className="text-xl font-bold">Plans Premium</h2>
        <p className="text-sm opacity-50 mt-1">Acces illimite sans publicite</p>
      </div>

      <div className="glass rounded-2xl p-4">
        <div className="text-sm font-semibold opacity-70 mb-3">Avantages Premium</div>
        <div className="space-y-2.5">
          {[
            [Icon.CheckCircle, "Acces illimite a tous les fichiers"],
            [Icon.Shield, "Aucune publicite a regarder"],
            [Icon.Clock, "Session permanente pendant toute la duree du plan"],
            [Icon.Headset, "Support client prioritaire"],
            [Icon.Zap, "Telechargements plus rapides"],
            [Icon.Star, "Badge exclusif sur votre profil"],
          ].map(([I, t], i) => {
            const C = I as typeof Icon.Star;
            return (
              <div key={i} className="flex items-center gap-3 text-sm">
                <C size={20} style={{ color: "var(--success)" }} />
                <span className="opacity-80">{t as string}</span>
              </div>
            );
          })}
        </div>
      </div>

      <div className="space-y-3">
        {PREMIUM_PLANS.map((p) => {
          const color = PLAN_COLORS[p.key];
          const PIcon = PLAN_ICONS[p.key];
          return (
            <div key={p.key} className="glass rounded-2xl p-4 relative" style={{ borderColor: `${color}1a` }}>
              {p.badge === "popular" && (
                <span className="absolute top-3 right-3 px-2 py-0.5 rounded-full text-[11px] font-semibold animate-pulse"
                  style={{ background: `${color}26`, color }}>Populaire</span>
              )}
              {p.badge === "best" && (
                <span className="absolute top-3 right-3 px-2 py-0.5 rounded-full text-[11px] font-semibold"
                  style={{ background: `${color}26`, color }}>Meilleur rapport</span>
              )}
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: `${color}1a`, color }}>
                  <PIcon size={22} />
                </div>
                <div>
                  <div className="font-bold" style={{ color }}>{PLAN_LABELS[p.key]}</div>
                  <div className="text-xs opacity-50">{p.duration}</div>
                </div>
              </div>
              <div className="flex flex-wrap gap-2 mb-3">
                <span className="px-2.5 py-1 rounded-full text-xs" style={{ background: "rgba(255,255,255,0.04)" }}>{p.fcfa} FCFA</span>
                <span className="px-2.5 py-1 rounded-full text-xs" style={{ background: "rgba(255,255,255,0.04)" }}>{p.cdf} CDF</span>
                <span className="px-2.5 py-1 rounded-full text-xs font-semibold" style={{ background: "rgba(255,255,255,0.06)" }}>{p.usd.toFixed(2)} $</span>
              </div>
              <div className="space-y-1.5 mb-3">
                {["Acces illimite aux fichiers","Aucune publicite","Session permanente","Support prioritaire"].map((a, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs opacity-60">
                    <Icon.Check size={12} style={{ color: "var(--success)" }} /> {a}
                  </div>
                ))}
              </div>
              <div className="flex gap-2">
                <button onClick={() => { hapticFeedback("impact","light"); setTonPlan(p); }}
                  className="flex-1 py-2.5 rounded-xl text-sm font-semibold flex items-center justify-center gap-1.5 active:scale-95"
                  style={{ background: `${color}26`, color }}>
                  <Icon.Diamond size={14} /> Payer avec TON
                </button>
                <button onClick={() => { hapticFeedback("impact","light"); setUsdtPlan(p); }}
                  className="flex-1 py-2.5 rounded-xl text-sm font-semibold flex items-center justify-center gap-1.5 active:scale-95"
                  style={{ background: "rgba(255,255,255,0.05)" }}>
                  <Icon.Dollar size={14} /> Payer en USDT
                </button>
              </div>
            </div>
          );
        })}
      </div>

      <div className="glass rounded-2xl p-4">
        <div className="text-sm font-semibold opacity-70 mb-3">Comparer les plans</div>
        <table className="w-full text-xs">
          <thead>
            <tr className="opacity-50">
              <th className="text-left py-2">Plan</th>
              <th className="text-left">Duree</th>
              <th className="text-right">Prix/jour</th>
              <th className="text-right">Total USD</th>
            </tr>
          </thead>
          <tbody>
            {PREMIUM_PLANS.map(p => (
              <tr key={p.key} className="border-t border-white/[0.04]" style={{ background: p.key === "or" ? "rgba(108,92,231,0.05)" : undefined }}>
                <td className="py-2 font-semibold" style={{ color: PLAN_COLORS[p.key] }}>{PLAN_LABELS[p.key]}</td>
                <td className="opacity-70">{p.duration}</td>
                <td className="text-right opacity-70">{(p.usd / p.days).toFixed(2)} $</td>
                <td className="text-right font-semibold">{p.usd.toFixed(2)} $</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="glass rounded-2xl p-4 text-center">
        <Icon.Phone size={32} className="mx-auto mb-2" style={{ color: "var(--accent-light)" }} />
        <div className="font-bold text-sm mb-2">Paiement Mobile Money</div>
        <div className="text-xs opacity-60 leading-relaxed mb-3">
          Pour payer via Orange Money, Wave, Flooz, M-Pesa ou tout autre moyen de paiement mobile, veuillez contacter directement notre equipe de support. Nous traitons les paiements manuellement sous 24 heures.
        </div>
        <button onClick={() => openTelegramLink(SUPPORT_TG)}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold active:scale-95"
          style={{ background: "rgba(0,184,148,0.12)", color: "var(--success)" }}>
          <Icon.Chat size={16} /> Contacter le support
        </button>
      </div>

      <div className="glass rounded-2xl p-4">
        <div className="text-sm font-semibold opacity-70 mb-3">Nos garanties</div>
        <div className="space-y-3">
          {[
            [Icon.ShieldCheck, "Paiement 100% securise via la blockchain TON"],
            [Icon.Refresh, "Activation instantanee apres confirmation du paiement"],
            [Icon.Headset, "Support disponible 7 jours sur 7 pour toute question"],
          ].map(([I, t], i) => {
            const C = I as typeof Icon.Star;
            return (
              <div key={i} className="flex items-center gap-3 text-sm">
                <C size={20} style={{ color: "var(--accent-light)" }} />
                <span className="opacity-80">{t as string}</span>
              </div>
            );
          })}
        </div>
      </div>

      <div className="glass rounded-2xl p-4">
        <div className="text-sm font-semibold opacity-70 mb-3">Questions frequentes</div>
        <Faq items={[
          { q: "Comment fonctionne le paiement TON ?", a: "Apres avoir clique sur Confirmer, votre portefeuille TON Connect s'ouvrira automatiquement. Validez la transaction et votre plan sera active instantanement." },
          { q: "Le paiement USDT est-il automatique ?", a: "Non, le paiement USDT est manuel. Envoyez le montant exact a l'adresse indiquee, puis cliquez sur J'ai paye et contactez le support avec la preuve de transaction." },
          { q: "Puis-je changer de plan en cours de route ?", a: "Oui, vous pouvez souscrire a un plan superieur a tout moment. Le temps restant de votre plan actuel sera ajoute au nouveau plan." },
          { q: "Que se passe-t-il si mon plan expire ?", a: "Votre acces reviendra au mode gratuit. Vous pourrez toujours utiliser les sessions gratuites en regardant des publicites." },
          { q: "Y a-t-il un remboursement possible ?", a: "Les paiements en crypto ne sont pas remboursables. Contactez le support avant de payer si vous avez des questions." },
        ]} />
      </div>

      {/* TON Sheet */}
      <BottomSheet open={!!tonPlan} onClose={() => setTonPlan(null)}>
        {tonPlan && (
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-center">Confirmer le paiement</h3>
            <div className="glass rounded-xl p-4 divide-y divide-white/[0.04]">
              {[
                ["Plan", <span style={{ color: PLAN_COLORS[tonPlan.key] }}>{PLAN_LABELS[tonPlan.key]}</span>],
                ["Duree", tonPlan.duration],
                ["Methode", "TON Connect"],
                ["Montant", `${tonPlan.usd.toFixed(2)} $ (equivalent TON)`],
              ].map(([l, v], i) => (
                <div key={i} className="flex justify-between py-2 text-sm">
                  <span className="opacity-60">{l}</span>
                  <span className="font-semibold">{v}</span>
                </div>
              ))}
            </div>
            <div className="flex gap-2">
              <button onClick={() => setTonPlan(null)} className="flex-1 py-3 rounded-xl font-semibold text-sm" style={{ background: "rgba(255,255,255,0.06)" }}>Annuler</button>
              <button onClick={() => { alert("TON Connect : Integration en production"); setTonPlan(null); }}
                className="flex-1 py-3 rounded-xl font-semibold text-sm text-white animate-glow-pulse"
                style={{ background: "var(--accent)" }}>Confirmer</button>
            </div>
          </div>
        )}
      </BottomSheet>

      {/* USDT Sheet */}
      <BottomSheet open={!!usdtPlan} onClose={() => setUsdtPlan(null)}>
        {usdtPlan && (
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-center">Paiement USDT</h3>
            <div className="text-center">
              <div className="text-xs opacity-50">Envoyez exactement</div>
              <div className="text-2xl font-bold" style={{ color: "#26a17b" }}>{usdtPlan.usd.toFixed(2)} USDT</div>
              <div className="text-xs opacity-50 mt-1">sur le reseau TON a cette adresse :</div>
            </div>
            <div className="w-36 h-36 mx-auto rounded-xl bg-white flex items-center justify-center text-gray-400 text-xs">
              <Icon.Phone size={48} />
            </div>
            <div className="font-mono text-[10px] break-all p-3 rounded-xl" style={{ background: "rgba(255,255,255,0.04)" }}>{USDT_WALLET}</div>
            <button onClick={() => { navigator.clipboard?.writeText(USDT_WALLET); hapticFeedback("notification","success"); }}
              className="w-full py-2.5 rounded-xl text-sm font-semibold" style={{ background: "rgba(108,92,231,0.12)", color: "var(--accent-light)" }}>
              Copier l'adresse
            </button>
            <div className="flex gap-2">
              <button onClick={() => setUsdtPlan(null)} className="flex-1 py-3 rounded-xl font-semibold text-sm" style={{ background: "rgba(255,255,255,0.06)" }}>Annuler</button>
              <button onClick={() => { openTelegramLink(SUPPORT_TG); setUsdtPlan(null); }}
                className="flex-1 py-3 rounded-xl font-semibold text-sm text-white" style={{ background: "#26a17b" }}>J'ai paye</button>
            </div>
          </div>
        )}
      </BottomSheet>
    </div>
  );
}
