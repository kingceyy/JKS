import { useEffect, useState } from "react";
import type { PlanKey } from "@/utils/constants";

export interface UserData {
  plan: PlanKey;
  premiumExpiry: string | null;
  sessionExpiry: string | null;
  totalSearches: number;
  weekSearches: number;
  dailySearches: number[];
  recentSearches: { query: string; timestamp: string }[];
}

const MOCK_DATA: UserData = {
  plan: "free",
  premiumExpiry: null,
  sessionExpiry: null,
  totalSearches: 247,
  weekSearches: 38,
  dailySearches: [8, 12, 5, 3, 6, 4, 0],
  recentSearches: [
    { query: "one piece film red", timestamp: new Date(Date.now() - 3600000).toISOString() },
    { query: "naruto shippuden vf", timestamp: new Date(Date.now() - 7200000).toISOString() },
    { query: "attack on titan saison 4", timestamp: new Date(Date.now() - 18000000).toISOString() },
    { query: "demon slayer movie", timestamp: new Date(Date.now() - 36000000).toISOString() },
    { query: "jujutsu kaisen 0", timestamp: new Date(Date.now() - 86400000).toISOString() },
    { query: "spy x family", timestamp: new Date(Date.now() - 172800000).toISOString() },
    { query: "dragon ball super hero", timestamp: new Date(Date.now() - 259200000).toISOString() },
    { query: "my hero academia", timestamp: new Date(Date.now() - 345600000).toISOString() },
    { query: "chainsaw man", timestamp: new Date(Date.now() - 432000000).toISOString() },
    { query: "bleach thousand year blood war", timestamp: new Date(Date.now() - 518400000).toISOString() },
  ],
};

export function useUserData() {
  const [data, setData] = useState<UserData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const t = setTimeout(() => { setData(MOCK_DATA); setLoading(false); }, 800);
    return () => clearTimeout(t);
  }, []);

  const activateSession = () => {
    setData((d) => d ? { ...d, sessionExpiry: new Date(Date.now() + 3600000).toISOString() } : d);
  };

  return { data, loading, activateSession, setData };
}

export function formatRelative(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const h = Math.floor(diff / 3600000);
  const d = Math.floor(diff / 86400000);
  if (d >= 1) return `il y a ${d}j`;
  if (h >= 1) return `il y a ${h}h`;
  const m = Math.floor(diff / 60000);
  return `il y a ${m}min`;
}

export function formatRemaining(iso: string | null) {
  if (!iso) return "Aucun";
  const diff = new Date(iso).getTime() - Date.now();
  if (diff <= 0) return "Expire";
  const d = Math.floor(diff / 86400000);
  const h = Math.floor((diff % 86400000) / 3600000);
  const m = Math.floor((diff % 3600000) / 60000);
  if (d > 0) return `${d}j ${h}h ${m}min`;
  if (h > 0) return `${h}h ${m}min`;
  const s = Math.floor((diff % 60000) / 1000);
  return `${m}min ${s}s`;
}
